<div id="footer">
    {!! Setting::value('footer_text', 'Powered by : DiscoverYourEvent v1.2, Copyright @ 2011-2015') !!}
    <div class="span pull-right">
        <span class="go-top"><i class="icon-arrow-up"></i></span>
    </div>
</div>
