<!-- Theme styles START -->
{!!HTML::style("assets/public/default2/css/bootstrap.css")!!}
{!!HTML::style("assets/public/default2/css/style.css")!!}
{!!HTML::style("assets/public/default2/css/img-effect.css")!!}
{!!HTML::style("assets/public/default2/css/animation.css")!!}
{!!HTML::style("assets/public/default2/css/bootstrap-select.css")!!}
{!!HTML::style("assets/public/default2/css/bootstrap-datetimepicker.css")!!}
{!!HTML::style("assets/public/default2/css/jquery.cleditor.css")!!}
{!!HTML::style("assets/public/default2/css/tipped.css")!!}

<!-- Global styles START -->
{!!HTML::style("assets/public/default2/font-awesome/css/font-awesome.min.css")!!}
<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700,900' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Global styles END -->
<script type="text/javascript" src='http://maps.google.com/maps/api/js?key=AIzaSyDE0yTu_hK_P14d4yk0IuDDUWEAqJr0y7A&libraries=places'></script>
{!!HTML::script("assets/public/default2/js/bootstrap.min.js")!!}
{!!HTML::script("assets/public/default2/js/bootstrap-select.js")!!}
{!!HTML::script("assets/public/default2/js/events-animation.js")!!}
{!!HTML::script("assets/public/default2/js/moment-with-locales.js")!!}
{!!HTML::script("assets/public/default2/js/jquery.cleditor.min.js")!!}
{!!HTML::script("assets/public/default2/js/bootstrap-datetimepicker.js")!!}
{!!HTML::script("assets/public/default2/js/tipped.js")!!}
{!!HTML::script("assets/public/default2/js/NovComet.js")!!}
@section('styles')
    {{-- Here goes the page level styles --}}
@show