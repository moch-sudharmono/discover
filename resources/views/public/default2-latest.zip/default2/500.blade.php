@extends("public/default2/_layouts._layout")

@section('content')
	  <div class="modal-dialog sign_login">
    <div class="tow-from">
      <div class="modal-header text-center not-found">
        <h1> 500 </h1>
		
		Oops! Something went wrong.</br> </br>
		
		<div class="col-md-offset-2 col-sm-offset-2 col-md-8">
		We are fixing it!</br>
    Please come back in a while..
		
		</br> </br></br> </br></br>
		
		</div>
      </div>

    </div>
  </div>
@stop
