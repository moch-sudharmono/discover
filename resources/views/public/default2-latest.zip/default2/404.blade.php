@extends("public/default2/_layouts._layout")

@section('content')
     <div class="modal-dialog sign_login">
    <div class="tow-from">
      <div class="modal-header text-center not-found">
        <h1> 404 </h1>
		
		Oops! You're lost.</br> </br>
		
		<div class="col-md-offset-2 col-sm-offset-2 col-md-8">
		We can not find the page you're looking for.
     <a href="{!!URL('/')!!}">Return home</a> or try the search bar below.
		

		
		</br> </br></br> </br></br>
		
		</div>
      </div>

    </div>
  </div>
@stop
