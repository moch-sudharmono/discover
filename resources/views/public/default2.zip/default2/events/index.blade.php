@extends('public/default2/_layouts._layout')
@section('styles')    
@stop
@section('content')
<script>
  function fbShare(url, title, image, winWidth, winHeight) {
	var winWidth = 520;
	var winHeight = 350;
    var winTop = (screen.height / 2) - (winHeight / 2);
    var winLeft = (screen.width / 2) - (winWidth / 2);
   window.open('http://www.facebook.com/sharer.php?s=100&p[title]='+ title +'&p[url]='+ url +'&p[images][0]='+ image, 'sharer', 'top='+ winTop +',left='+ winLeft +',toolbar=0,status=0,width='+ winWidth + ',height=' + winHeight);
  }
  var twitterHandle = 'DiscoverYourEvent';
	function tweetEvent(url, title) {
	  window.open('https://twitter.com/share?url='+escape(url)+'&text='+title+ 'via@' + twitterHandle, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');
	 return false; 
	}
 function linedinEvent(url, title) {
  var intWidth = intWidth || '500';
  var intHeight = intHeight || '400'; 
  var strParam = 'width=' + intWidth + ',height=' + intHeight;
  objWindow = window.open('http://www.linkedin.com/shareArticle?url='+url,title,strParam).focus();
 }
</script>
 <div class="full">	
      @if(!empty($event_data[0]->event_image))		  
	  @if(is_numeric($event_data[0]->event_image)) 	 
   <?php $evtoimg = DB::table('event_catimages')->where('id', '=', $event_data[0]->event_image)->select('id','ecat_name','ecat_path','ecat_image')->get(); ?>	
    @if(!empty($evtoimg[0]->id))
    	<?php $bac_img = URL::to('uploads/'.$evtoimg[0]->ecat_path.'/'.$evtoimg[0]->ecat_name.'/'.$evtoimg[0]->ecat_image); ?>	
     @else
		<?php $bac_img = URL::to('assets/public/default2/images/events-pic1.jpg'); ?> 		
    @endif 
  @else
	  
		<?php $bac_img = URL::to('uploads/events/'.$event_data[0]->account_type.'/'.$event_data[0]->event_image); ?>
	 @endif 	
      @else
		<?php $bac_img = URL::to('assets/public/default2/images/events-pic1.jpg'); ?> 
	  @endif
		 <div class="events-page" style="background:url('{!!$bac_img!!}') no-repeat;">
		  <div class="container cont">				  
				  <div class="event-detail col-md-8 col-sm-8 evnt">
                    <h3>{!! ucfirst($event_data[0]->event_name) !!}</h3>					
				<?php 
					 if(!empty($event_data[0]->event_date)) {
					   $ev_date = date('M d, Y', strtotime($event_data[0]->event_date));
					 } else {
						$ev_date = 'n/a'; 
					 }
				  if(!empty($event_data[0]->country)){	 
				   $getvcy = DB::table('countries')->where('id', '=', $event_data[0]->country)->select('name')->get(); 
                   $countryn = $getvcy[0]->name;			   
				  } else {
				   $countryn = null;	 
				  }  
				  if(!empty($event_data[0]->event_description)){
					$shortDescription = '';
					$fullDescription = trim(strip_tags($event_data[0]->event_description));
					$initialCount = 100;
				   if(strlen($fullDescription) > $initialCount) {
					$shortDescription = substr($fullDescription,0,$initialCount)."…";
				   } else {
         			$shortDescription = $fullDescription;
				   }
				  } else {
					$shortDescription = null;  
				  }
				?>					
                    <p><span class="date-text"> Date: </span> {!! $ev_date !!} @ {!! $event_data[0]->event_time !!}<br>
                     <span class="date-text"> Venue: </span>  {!! $event_data[0]->event_venue !!}<br>
                    <span class="date-text">  Address:</span>  
					  @if(!empty($event_data[0]->event_address))
					   {!!$event_data[0]->event_address!!},
					  @endif
					  @if(!empty($event_data[0]->address_secd))
						{!!$event_data[0]->address_secd!!},  
					  @endif	
					  @if(!empty($event_data[0]->city))
						{!!$event_data[0]->city!!},  
					  @endif
					  @if(!empty($event_data[0]->state))
						{!!$event_data[0]->state!!},  
					  @endif
					 {!! $countryn !!}
					 <br>
					@if(!empty($event_data[0]->event_cost) && $event_data[0]->event_cost != 'free')						
                       <span class="date-text">Tickets:</span> <font color="#0c7ab3"> 
					     $ {!! $event_data[0]->event_price !!}	
					  <a href="{{$event_data[0]->ticket_surl}}" target="_blank"><u> Buy Tickets</u></a></font><br>
					@endif	
                  <span class="date-text">  Attending People: </span>  <font color="#0c7ab3"> {{ $attending_people }}</font></p>					  				            
		  @if(!empty($your_event[0]->e_id))	
            <a onclick="unattend({!! $your_event[0]->e_id !!})" href="javascript:void(0)" class="save-event">Unattend</a>		
          @else
			<a onclick="saveEvent()" href="javascript:void(0)" class="save-event"> Attend </a>  
          @endif 
<?php 
 if(!empty($event_data[0]->account_id) && !empty($clid)){
  $followus = DB::table('user_follows')->where('follow_id', '=', $event_data[0]->account_id)->where('u_id', '=', $clid)->where('follow_type', '=', 'account')->select('id','follow')->get(); 
?>
				 @if(!empty($followus[0]->id))
				   @if($followus[0]->follow == 'y')	  
					<a href="javascript:void(0)" class="unfollow-event save-event">Unfollow</a>
				   @endif
				  @else	  
<?php $checm = DB::table('account_details')->where('id', '=', $event_data[0]->account_id)->where('u_id', '!=', $clid)->select('id')->get(); ?>			
    @if(!empty($checm[0]->id))		  
	 <a href="javascript:void(0)" onClick="followEvent({!! $event_data[0]->account_id !!})" class="follow-event save-event">Follow</a>
 	@endif  				 
   @endif  				 
<?php } ?>
@if(!empty($accdata[0]->id)) 
  <a href="{!!URL($accdata[0]->account_url)!!}" class="save-event" target="_blank" title="{!!$accdata[0]->name!!}">{!!$accdata[0]->name!!} Page</a>		
@endif	
 <div class="help-block with-errors" id="error-lreq"></div>		  
		   <span class="col-md-12 full-success alert mar-top" id="full-success" style="display:none">
              <button data-dismiss="alert" aria-label="close" class="close">&times;</button>
              <strong>Success!</strong> <span id="es-mess"></span>
             </span>  
        </div>
	 </div>
 </div>
			<div class="container mar-top">	
			 <input type="hidden" name="_token" id="_token" value="{{ csrf_token() }}">	
                  <div class="event-detail col-md-7 col-sm-7 col-xs-12 ">				  
                    <h3>{!! ucfirst($event_data[0]->event_name) !!}</h3>					
					<?php 
					 if(!empty($event_data[0]->event_date)) {
					   $ev_date = date('M d, Y', strtotime($event_data[0]->event_date));
					 } else {
						$ev_date = 'n/a'; 
					 }
					?>					
                    <p class="ev-deat"><span class="date-text"> Date: </span>  {!! $ev_date !!} @ {!! $event_data[0]->event_time !!}<br>
					 <span class="date-text">Venue:</span>  {!! $event_data[0]->event_venue !!}<br>
                     <span class="date-text"> Address: </span>
					  @if(!empty($event_data[0]->event_address))
					   {!!$event_data[0]->event_address!!},
					  @endif
					  @if(!empty($event_data[0]->address_secd))
						{!!$event_data[0]->address_secd!!},  
					  @endif	
					  @if(!empty($event_data[0]->city))
						{!!$event_data[0]->city!!},  
					  @endif
					  @if(!empty($event_data[0]->state))
						{!!$event_data[0]->state!!},  
					  @endif
					 {!! $countryn !!}<br>
			 @if(!empty($event_data[0]->event_cost) && $event_data[0]->event_cost != 'free') 						
                  <span class="date-text"> Tickets: </span> <span class="col-blue"> <strong>
			           $ {!! $event_data[0]->event_price !!}
			   <a href="{{$event_data[0]->ticket_surl}}" target="_blank"><u> Buy Tickets</u></a></strong> </span><br>
			@endif	
                     <span class="date-text">  Attending People: </span>  <font color="#0c7ab3"> {{ $attending_people }}</font>										  
		 </p>
	 <div class="share-text">
	 <h2>SHARE THIS</h1>
 	  <div class="social-co">
<a onClick="fbShare('{!!URL('event/'.$event_data[0]->event_url)!!}','{!!ucfirst($event_data[0]->event_name)!!}','{!!URL::to($bac_img)!!}')" href="javascript:void(0);">
	<img src="{!!URL::to('assets/public/default2/images/facebook1.png')!!}"/>
</a>	
<a onClick="tweetEvent('{!!URL('event/'.$event_data[0]->event_url)!!}','{!!ucfirst($event_data[0]->event_name)!!}')" href="javascript:void(0);">
	<img src="{!!URL::to('assets/public/default2/images/twitter.png')!!}"/>
</a>
<a onClick="linedinEvent('{!!URL('event/'.$event_data[0]->event_url)!!}','{!!ucfirst($event_data[0]->event_name)!!}')" href="javascript:void(0);">
	<img src="{!!URL::to('assets/public/default2/images/share.png')!!}"/>
</a> 
<a href="javascript:void(0);" data-toggle="modal" data-target="#share-pop-up">
	<img src="{!!URL::to('assets/public/default2/images/share1.png')!!}"/>
</a>
	<!-- Share pop_up Start-->
	<div id="share-pop-up" class="modal fade" role="dialog" data-backdrop="static">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content sign_up-form">
					  <div class="modal-header text-center">
						<button type="button" class="close pup-close" data-dismiss="modal">&times;</button>
						<h3 class="modal-title text-left">Share this with your friend</h3>
						<div class="col-md-12" id="error-all"></div>
					  </div>
					   <div class="col-md-12" id="error-lpopall"></div>
				<div class="modal-body">
				 <form class="form-inline" id="sharewithf" method="post">
						<div class="form-group col-lg-12 col-sm-12 col-xs-12 share-mr">
							Friend's email
						</div>
						  <div class="form-group col-lg-12 col-sm-12 col-xs-12">
							<input type="email" name="femail" id="femail" placeholder="Email Address" class="form-control sgmail" required/>
							  <div class="help-block with-errors" id="error-slemail"></div>
						  </div>
						  <div class="form-group col-lg-12 col-sm-12 col-xs-12 share-mr">
							Message  
						</div>
						<input type="hidden" value="{!!$event_data[0]->event_url!!}" name="eurl"/>
						  <div class="form-group col-lg-12 col-sm-12 col-xs-12">
							<textarea placeholder="Textarea" name="fmsg" id="fmsg" rows="3" class="form-control" required></textarea>
							 <div class="help-block with-errors" id="error-fn"></div>
						  </div>
						  <div class="share-content">
						   	<div class="col-lg-3 col-sm-4 col-xs-12 rem-text">
							  <img src="{!!$bac_img!!}"/>
							 </div>
						    <div class="col-lg-9 col-sm-8 col-xs-12">							
							<h5>{!! ucfirst($event_data[0]->event_name) !!}</h5>
							<p>{!!$shortDescription!!}</p>
							</div>
							<input type="hidden" name="_token" id="_token" value="{!!csrf_token()!!}">	
							   <div class="col-lg-12 col-sm-12 col-xs-12 share-btn">
							   <input type="reset" id="resetThis" style="display: none"/>
								<input type="submit" class="save-event" value="Share"/>
							   </div>
							</div>
				 </form>
				</div>
			</div>
		</div>
	</div>
	<!--Share pop_up END--> 
<!--	   <a href="#"> <i class="fa fa-facebook"></i> </a>  
		<a href="#"> <i class="fa fa-twitter"></i></a>-->
					</div>
					</div>					  
                    <br>
                  </div>					  
<div class="col-md-5 col-sm-5 col-xs-12 events-map" id="event-map"></div>
	<div class="descrip col-md-12 col-sm-12 col-xs-12">
        <p class="text bor"> <span class="des-icon"> </span> <strong>Description:</strong><br>
                      </p>
                      <div class="text1">{!! $event_data[0]->event_description !!}</div>
    </div>
 </div>
 </div>
@stop
@section('scripts')
<script>  
  function unattend(evid){
   if(evid != null){
	 var tken = jQuery( "input#_token" ).val();  
	 var postdt = {evntid: evid, _token: tken};
	var datapost = $.post('{!!URL("event/unattendEvent")!!}', postdt);
	 datapost.done(function( data ) {
	  if(data == 'succ'){
		 $("#full-success").css("display", "block");
		 $("#es-mess").html('You are successfully unattend the event');		
		setTimeout(function () {
		 window.location = '{!!URL("event/".$event_data[0]->event_url)!!}';
		}, 500); 	  
	  } else {	
		window.location='{!!URL("event/".$event_data[0]->event_url)!!}';	
	  }	
	 });	
   } 
  }
  
  function saveEvent(){   
    $.ajax({
       type: "GET",
       url: '{!!URL("saveEvent/".$event_data[0]->event_url)!!}',
     beforeSend: function(){ },
     complete: function(){ },       	
    success: function(data) { 
	 if(data == 'succ'){
	  $("#full-success").css("display", "block");
		$("#es-mess").html('Event successfully saved on your account');		
	  setTimeout(function () {
        window.location = '{!!URL("event/".$event_data[0]->event_url)!!}'; 
      }, 500);		 
	 }        
    }
   });
  }

 function followEvent(eid) {	 
 var token = jQuery('#_token').val();
        var postdata = {'ascid': eid, '_token': token};
		//jQuery("#follow-page").html('Following');
	    var datapst = $.post( '{!!URL("account/follow")!!}', postdata );
	   datapst.done(function( data ) {
	   if(data == 'success'){   
	    window.location='{!!URL("/event/".$event_data[0]->event_url)!!}';		 
	   } else { 
	    // jQuery("#follow-page").html('Follow');
		 jQuery("#error-lreq").html('Login required');  
	   } 	
	  });
 }  
 
  var geocoder = new google.maps.Geocoder(); 
  function mgeocodeAddress(mlocations, orgtitles) {
    geocoder.geocode({address:mlocations}, function (results,status)
      { 
         if (status == google.maps.GeocoderStatus.OK) {
          var p = results[0].geometry.location;
          var lats=p.lat();
          var lngs=p.lng();
		  var myLatLng = {lat: lats, lng: lngs};
		var map = new google.maps.Map(document.getElementById('event-map'), {
          zoom: 6,
          center: myLatLng
        });
		var marker = new google.maps.Marker({
          position: myLatLng,
          map: map,
          title: orgtitles
        });
        } else {  }
      }
    );
  } 
var mlocations = ['<?php echo implode('","', $maddArr);?>'];
var morg_title = ['<?php echo ucfirst($event_data[0]->event_name);?>'];
mgeocodeAddress(mlocations[0],morg_title[0]);

 $("#sharewithf").submit(function(event) {
   event.preventDefault();
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;	  
	var frdmail = $( "input#femail" ).val();
   var frdmsg = $( "#fmsg").val();
    if(frdmsg == '' || frdmsg == ' '){
      $( "#error-fn" ).html( "Message field required" );	
	 return false;
	}	
	 if(frdmail.match(mailformat))
	{	
	  var datapst = $.post('{!!URL("sharewfriend")!!}', $('#sharewithf').serialize());
	  datapst.done(function( data ) {
	  if(data == 'error'){
		  $("#error-all").removeClass('full-success');
		$("#error-all").addClass('full-error');
		$( "#error-all" ).html( "Something wrong! please try again" );	
	  } else {	 
		$("#error-all").removeClass('full-error');
		$("#error-all").addClass('full-success');
		$( "#resetThis" ).trigger("click");
		$( "#error-all" ).html("Shared succefully!");	
	  }	
	 });
	} else {
	  $("#error-slemail").show();
	  $( "#error-slemail" ).html( "That email address is invalid" );
		return false;
	}	
 }); 
</script>
@stop