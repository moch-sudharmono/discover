 @if(!empty($refine_events[0]->id))
	@foreach($refine_events as $aet) 
     <div class="rock-event {!! $cust_class !!}">
     <div class="evnt-pic col-md-5 col-ms-5 col-xs-12">
	  @if(!empty($aet->event_image))	
@if(is_numeric($aet->event_image)) 	 
   <?php $evtoimg = DB::table('event_catimages')->where('id', '=', $aet->event_image)->select('id','ecat_name','ecat_path','ecat_image')->get(); ?>	
    @if(!empty($evtoimg[0]->id))	
     <img src="{!!URL::to('uploads/'.$evtoimg[0]->ecat_path.'/'.$evtoimg[0]->ecat_name.'/'.$evtoimg[0]->ecat_image)!!}" class="img-responsive"/>
    @endif 
  @else		  
		<img src="{!!URL::to('uploads/events/'.$aet->account_type.'/'.$aet->event_image)!!}" class="img-responsive"/>
 @endif 	
	  @else
		<img src="{!!URL::to('assets/public/default2/images/events-pic1.jpg')!!}" class="img-responsive"> 	  
	  @endif
	 </div>
     <div class="evnt-con col-md-7 col-ms-7 col-xs-12">
<h4> 
 <a href="{!!URL('event/'.$aet->event_url)!!}" class="delegation-ajax" data-tipped-options="ajax:{data:{ event: '{!! $aet->event_url !!}', _token: '{!! csrf_token() !!}' }}"> 
  {!! ucfirst($aet->event_name) !!} 
 </a> 	
</h4>
                <div class="date"> <span class="date-icon"> </span>
				<?php 
				 if(!empty($aet->event_date)) {
				   $aev_date = date('M d, Y', strtotime($aet->event_date));
				 } else {
				   $aev_date = 'n/a'; 
				 }
				?>
			   {!! $aev_date !!} @ {!! $aet->event_time !!} 
				</div>
                <div class="location"> <span class="location-icon"> </span> {!! $aet->event_venue !!} / {!! $aet->event_address !!} </div>
        <div class="price"> <span class="price-icon"> </span> 
		<strong>
				 @if($aet->event_cost == 'paid')
			   <?php $alet_price = explode("-",$aet->event_price ); ?>
			    @if(!empty($evnt_price[0]))
				<?php $alet_prc = '$'.$alet_price[0]; 			
			      for ($x = 1; $x < sizeof($alet_price); $x++) {
					  $alet_prc .= ' - $'.$alet_price[$x];
				  }			 
				 ?> 
				 {!! $alet_prc !!}
				@else
				${!! $aet->event_price !!}	
                @endif					
			   @else
			    {!! ucfirst($aet->event_cost) !!}  
               @endif  		
		</strong> </div>
          <?php $allevt_ct = DB::table('users_events')->where('e_id', '=', $aet->id)->count(); ?>		
         <div class="attend"> People Attending : <span class="blue-col"> <a href="#"> {!! $allevt_ct !!} </a> </span></div>
		<div>
	<!-- <a class="event-more" href="{!!URL('event/'.$aet->event_url)!!}">More Details</a> -->		
		<?php $ur_event = DB::table('users_events')->where('e_id', '=', $aet->id)->where('u_id', '=', $clid)->select('e_id')->get(); ?>
		  @if(!empty($ur_event[0]->e_id))	
           <a onclick="unattend({!! $ur_event[0]->e_id !!})" href="javascript:void(0)" class="save-event event-attend">Unattend</a>		
          @else
		   <a onclick="saveEvent('{!! $aet->event_url !!}')" href="javascript:void(0)" class="save-event event-attend">Attend</a> 
          @endif 	
<?php  
 if(!empty($aet->account_id)){
  $followu = DB::table('user_follows')->where('follow_id', '=', $aet->account_id)->where('u_id', '=', $clid)->where('follow_type', '=', 'account')->select('id','follow')->get(); 
?>		  
	 @if(!empty($followu[0]->id))
	  @if($followu[0]->follow == 'y')	  
		<a href="javascript:void(0)" class="unfollow-event">Following</a>
	  @endif
    @else	
<?php $checm = DB::table('account_details')->where('id', '=', $aet->account_id)->where('u_id', '!=', $clid)->select('id')->get(); ?>
    @if(!empty($checm[0]->id))		  
	 <a href="javascript:void(0)" onClick="followEvent({!! $aet->account_id !!})" class="follow-event">Follow</a>
 	@endif  				 
   @endif 
<?php } ?>	
		</div>	   
     </div>
     </div>
	 @endforeach
    @else 
	 <div class="rock-event"> Empty! not found </div>  
    @endif 
<input type="hidden" id="rs_type" value="ref_search"/>
<script>
 $('#cpage').val('{!! $refine_events->currentPage() !!}');
 $('#max_page').val('{!! $refine_events->lastPage() !!}');
</script>