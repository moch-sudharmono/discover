@extends('public/default2/_layouts._layout')
@section('styles')    
@stop
@section('content')
  <section class="creat-page">
  <div class="form-bg"> 
    <!-- tabs right -->
    <div class="tabbable tabs-right">
      <div class="tab-content left-side col-md-offset-2 col-md-8 col-md-offset-2 col-sm-12 col-xs-12" >
        <div class="tab-pane active" id="1">
          <div class="personal-form account-user">
           
              <ul class="nav nav-tabs" id="tabs">
		 <form class="form-inline" method="post" enctype="multipart/form-data">
                <li class="active">
					  
                  <div class=" per-1 active">
                    <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12 ">
                      <h4 class="heading"> Set Up your Account</h4>
					  </div>
					    @if ($errors->has())
						   <div class="col-md-12 full-error alert">
					   <button data-dismiss="alert" aria-label="close" class="close">&times;</button>
					   You have some form errors. Please check below.</div>						
						@endif
					   <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12 ">
                     <h3>Account Details</h3>
					    <div class="col-lg-12 col-sm-12 col-xs-12 rem-text rt row">
                      <input type="checkbox" value="y" name="enotification_status">
                      Receive Email Event Notification
					  </div>
                    </div>
                  
				    <div class="col-lg-12 col-sm-12 col-xs-12 choose-catagories  ">
                     <h3 class="option1">Choose Interested Categories</h3>
					 
					 <div class="catagories">
					<div class="row">	
 <select id="tokens" class="selectpicker" name="interested_catagories[]" multiple data-live-search="true">
   <option>Select Categories</option>
   @if(!empty($evtsdata[0]))
	@foreach($evtsdata as $etdata)
     <option data-tokens="{!! $etdata !!}" value="{!! $etdata !!}">{!! $etdata !!}</option>
    @endforeach 
   @endif	
  </select>
						
					</div>
					
					</div>
					 
					 
                    </div>
					
					
				<div class="col-lg-12 col-sm-12 col-xs-12 ">
					<div class="form-group sel pick-event">
					<h3>Pick a range of Events</h3>
					<div class="col-lg-6 col-sm-6 col-xs-12 row ">
                        <select title="event" name="selected_event" class="selectpicker bs-select-hidden" id="lunch">
						<option class="bs-title-option events-select" value="">Select Event..</option>
                          <option>Category select 1</option>
                          <option>Category select 2</option>
                          <option>Category select 3</option>
                          <option>Category select 4</option>
                          <option>Category select 5 </option>
                        </select>
					</div>
                      </div>
					  </div>
					  <input type="hidden" value="{{$grd_id}}" name="grd_id"/>
					  <div class="col-lg-12 col-sm-12 col-xs-12 rem-text rt">
                      <input type="checkbox" value="y" name="email_nbusiness" id="option">
                      Receive email notifications from business you follow
					  </div>
					  <div class="col-lg-12 col-sm-12 col-xs-12 rem-text rt">
                      <input type="checkbox" value="y" name="email_nupdate" id="option">
                      Receive email notifications on site updates & features.
					  </div>
					  </div>
                </li>
				 <input type="hidden" name="_token" value="{{ csrf_token() }}">	
                <div class="form-group col-lg-12 col-sm-12 col-xs-12"> 
			<input type="submit" class="btn discover-btn" value="Finish"/>            
        </div>
		 </form>
		    <form class="form-inline" method="post" enctype="multipart/form-data">
			 <input type="hidden" name="ckd" value="yes">	
			<input type="hidden" name="_token" value="{{ csrf_token() }}">	
		      <div class="form-group col-lg-12 col-sm-12 col-xs-12"> 
			  <input type="submit" class="btn discover-btn" value="Skip"/>
			 </div>
			</form> 
          </ul>
            
          </div>
        </div>
      </div>
    </div>
    <!-- /tabs --> 
  </div>
  </div>
  </div>
 </section>
@stop
@section('scripts')
  <script>
    jQuery(document).ready(function(){
		 
	});
 </script>
@stop