@extends('public/default2/_layouts._layout')
@section('styles')    
@stop
@section('content')
{!!HTML::style("assets/public/default2/css/jquery.filer-dragdropbox-theme.css")!!}
{!!HTML::style("assets/public/default2/css/jquery.filer.css")!!}
 {!!HTML::script("assets/public/default2/js/locationpicker.jquery.js")!!}
  {!!HTML::script("assets/public/default2/js/jquery.filer.min.js")!!}
  {!!HTML::script("assets/public/default2/js/custom.js")!!}
<?php
 $st_cvs = array("12:00am", "12:30am", "01:00am","01:30am", "02:00am", "02:30am","03:00am", "03:30am", "04:00am","04:30am", "05:00am", "05:30am", "06:00am", 
 "06:30am", "07:00am","07:30am", "08:00am", "08:30am","09:00am","09:30am", "10:00am", "10:30am","11:00am", "11:30am", "12:00pm","12:30pm", "01:00pm", "01:30pm",
 "02:00pm", "02:30pm", "03:00pm","03:30pm", "04:00pm", "04:30pm","05:00pm", "05:30pm","06:00pm","06:30pm","07:00pm","07:30pm","08:00pm","08:30pm", "09:00pm",
 "09:30pm","10:00pm","10:30pm","11:00pm", "11:30pm");
?>   
 <section class="sec">
      <div class="tabbable tabs-left">
       @include("public/default2/_layouts._AccountMenu")
         <div class="tab-content form-group col-lg-8 col-sm-8 col-xs-12 ">
		 <h3> Update Event </h3>
		  <form class="form-inline" method="post" action="" enctype="multipart/form-data">
		  
		  @if(count($errors) > 0)
			<span class="col-md-12 full-error alert">
             <button data-dismiss="alert" aria-label="close" class="close">&times;</button>
             <strong>Whoops!</strong> There were some problems with your input.
            </span>	
		  @endif
		  
		   @if(!empty(Session::get('invl_url')) || !empty(Session::get('inv_tkurl')))
			<span class="col-md-12 full-error alert">
             <button data-dismiss="alert" aria-label="close" class="close">&times;</button>
             <strong>Whoops!</strong> There were some problems with your input.
            </span>	  
		   @endif	
            @if(!empty(Session::get('req_evprice')) || !empty(Session::get('failed_upfile')))
			 <span class="col-md-12 full-error alert">
              <button data-dismiss="alert" aria-label="close" class="close">&times;</button>
              <strong>Whoops!</strong> There were some problems with your input.
              </span>	
		    @endif	
        <h4 class="event-head"><span class="ico-box ico--small">1</span> Event Details</h4>			
		 <div class="form-group col-lg-12 col-sm-12 col-xs-12">
              <label class="col-lg-3 col-sm-3 col-xs-12 row"> <span class="require-val">*</span>Event will occur:
              </label>
              <div class="col-lg-6 col-sm-9 col-xs-12 send"> 
			   <input type="radio" name="event_type" class="event_type" value="indoor" @if(!empty($edit_event[0]->event_type) && $edit_event[0]->event_type == 'indoor') checked @endif /> Indoor  &nbsp; | &nbsp;
               <input type="radio" name="event_type" class="event_type" value="outdoor" @if(!empty($edit_event[0]->event_type) && $edit_event[0]->event_type == 'outdoor') checked @endif /> Outdoor 
              </div>
         </div>			
			<div class="form-group col-lg-12 col-sm-12 col-xs-12">
              <label class="col-lg-3 col-sm-3 col-xs-12 row"> <span class="require-val">*</span>Event Categories:</label>
              <div class="col-lg-6 col-sm-9 col-xs-12 send" id="event_category"> 
			   <img src="{!!URL::to('assets/public/default2/images/progress.gif')!!}" class="img-responsive" style="width:30px"/>
              </div>
			  {!! $errors->first('event_catid', '<span class="help-block with-errors">Event Category is required field</span>') !!}	
            </div>	
            <div class="form-group col-lg-12 col-sm-12 col-xs-12">
              <label class="col-lg-3 col-sm-3 col-xs-12 row"> <span class="require-val">*</span>Event Name :
              </label>
              <div class="col-lg-6 col-sm-9 col-xs-12 send"> 
                  <input type="text" name="event_name" class="form-control" value="{!!$edit_event[0]->event_name!!}" required />
				  {!! $errors->first('event_name', '<span class="help-block with-errors">:message</span>') !!} 				 
              </div>
            </div>
			
			
		<div class="form-group col-lg-12 col-sm-12 col-xs-12">
		  <label class="col-lg-3 col-sm-3 col-xs-12 row">Event image:</label>
		 <div class="col-lg-6 col-sm-6 col-xs-12">
		 <div class="col-lg-2 col-sm-2 col-xs-12">
	@if(!empty($edit_event[0]->event_image))	
	 @if(is_numeric($edit_event[0]->event_image)) 
<?php $evtoimg = DB::table('event_catimages')->where('id', '=', $edit_event[0]->event_image)->select('id','ecat_name','ecat_path','ecat_image')->get(); ?>
      @if(!empty($evtoimg[0]->id))			   
	   <img src="{!!URL::to('uploads/'.$evtoimg[0]->ecat_path.'/'.$evtoimg[0]->ecat_name.'/'.$evtoimg[0]->ecat_image)!!}" class="img-responsive"/>
      @endif
     @else  
      <img src="{!!URL::to('uploads/events/'.$edit_event[0]->account_type.'/'.$edit_event[0]->event_image)!!}" class="img-responsive"/>
     @endif  
	@else
	 n/a	
	@endif
        </div>	
    <div class="col-lg-10 col-sm-9 col-xs-12">		 
		<div id="content">
			<input type="file" name="event_image" id="filer_input2">
		  <small> We recommend using at least a 2160x1080px (2:1 ratio) image that's no larger than 2MB</small>	
		</div>
	<div id="sel_ourimg" style="display:none"> </div>
	<input type="hidden" value="" name="our_pid" id="our_pid"/>
			 {!! $errors->first('event_image', '<span class="help-block with-errors">:message</span>') !!}	
			 	@if(!empty(Session::get('failed_upfile')))
				 <span class="help-block with-errors">We recommend using at least a 2160x1080px (2:1 ratio) image that's no larger than 2MB.</span>
			    @endif   
            <span>Don't have an image?<br>Use one of 
			<a href="javascript:void(0)" data-toggle="modal" data-target="#our-img-up"> ours </a></span>	
	        <div id="our-img-up" class="modal fade" role="dialog">
              <div class="modal-dialog">
                <div class="modal-content sign_up-form" id="one_ours">
				 <img src="{!!URL::to('assets/public/default2/images/progress.gif')!!}" class="img-responsive" style="width:30px"/>
				</div>
              </div>
            </div>	
          </div>				
         </div>				
        </div>
			<div class="form-group col-lg-12 col-sm-12 col-xs-12">
              <label class="col-lg-3 col-sm-3 col-xs-12 row"> <span class="require-val">*</span>Venue/Location:
              </label>
              <div class="col-lg-9 col-sm-9 col-xs-12 send">  
<?php
   $all_address = null; 
      if(!empty($edit_event[0]->event_venue)){
	   $all_address .= $edit_event[0]->event_venue;
      }			  
	  if(!empty($edit_event[0]->event_address)){
	   if(!empty($all_address)){		 	  
	    $all_address .= ','.$edit_event[0]->event_address;  
	   } else {
		$all_address = $edit_event[0]->event_address;   
	   }
      }	
     if(!empty($edit_event[0]->address_secd)){
	   if(!empty($all_address)){		 	  
	    $all_address .= ','.$edit_event[0]->address_secd;  
	   } else {
		$all_address = $edit_event[0]->address_secd;   
	   }
      }	
     if(!empty($edit_event[0]->city)){
	   if(!empty($all_address)){		 	  
	    $all_address .= ','.$edit_event[0]->city;  
	   } else {
		$all_address = $edit_event[0]->city;   
	   }
      }	
	  
 if(!empty($edit_event[0]->state) && !empty($edit_event[0]->country)){ 
  $getsdata = DB::table('states')->where('country_id', '=', $edit_event[0]->country)->where('name', '=', $edit_event[0]->state)->select('id','name')->get();
  if(!empty($getsdata[0]->id)){
	$staten = $getsdata[0]->name;
  } else {
	$staten = $edit_event[0]->state;
  } 
 } else{
  $staten = null;	 
 }
   if(!empty($staten)){
	   if(!empty($all_address)){		 	  
	    $all_address .= ','.$staten;  
	   } else {
		$all_address = $staten;   
	   }
   }

  if(!empty($edit_event[0]->country)){ 
   $getcdata = DB::table('countries')->where('id', '=', $edit_event[0]->country)->select('id','name')->get(); 
   if(!empty($getcdata[0]->id)){
	 $sel_count = '<option value="'.$getcdata[0]->id.'" selected >'.$getcdata[0]->name.'</option>'; 
   }    
  } else {
	$sel_count = null;  
  }
 if(!empty($edit_event[0]->country)){
	   if(!empty($all_address)){		 	  
	    $all_address .= ','.$getcdata[0]->name;  
	   } else {
		$all_address = $getcdata[0]->name;   
	   }
   }  
 ?>	  
<div id="slocation">
	<input type="text" name="event_all" id="us3-address" class="form-control" value="{!!$all_address!!}" />				 
				   <input type="hidden" class="form-control" id="us3-radius"/>
				   <input type="hidden" class="form-control" id="us3-lat"/>
				   <input type="hidden" class="form-control" id="us3-lon"/>
				   <a href="javascript:void(0)" id="open_alldetail">Enter Address</a>
 {!! $errors->first('event_venue', '<span class="help-block with-errors">Venue/Location field is required</span>') !!} 
 {!! $errors->first('country', '<span class="help-block with-errors">Venue/Location field is required</span>') !!} 
</div> 
<div id="alloc_fileds" style="display:none">		
<div class="map-enter col-md-7 col-sm-12 col-xs-12">
<input type="text" name="event_venue" placeholder="Enter the venue's name" id="us3-venue" class="form-control" value="{!!$edit_event[0]->event_venue!!}"/> 
 {!! $errors->first('event_venue', '<span class="help-block with-errors">:message</span>') !!} 	
<input type="text" name="event_address" placeholder="Address" id="ev_address" class="form-control" value="{!!$edit_event[0]->event_address!!}"/>	
  {!! $errors->first('event_address', '<span class="help-block with-errors">:message</span>') !!} 
<input type="text" name="address_secd" placeholder="Address 2" id="ev_addres" class="form-control" value="{!!$edit_event[0]->address_secd!!}"/>	
   {!! $errors->first('address_secd', '<span class="help-block with-errors">:message</span>') !!} 
<input type="text" name="city" placeholder="City" id="evt_city" class="form-control full" value="{!!$edit_event[0]->city!!}"/>	  
 {!! $errors->first('city', '<span class="help-block with-errors">:message</span>') !!} 
<input type="text" name="state" placeholder="State" id="evt_state" class="form-control full" value="{!! $staten !!}"/>   
{!! $errors->first('state', '<span class="help-block with-errors">:message</span>') !!} 	
<input type="text" name="zip_code" placeholder="Zip/Postal" id="evt_zip" class="form-control full" value="{!! $edit_event[0]->zip_code !!}"/>  
 {!! $errors->first('zip_code', '<span class="help-block with-errors">:message</span>') !!} 	
 <select name="country" id="us5-country" required>
 {!! $sel_count !!}
  <option value="">Please select a country.</option> 
  @if(!empty($cuntd[0]->id))
   @foreach($cuntd as $cdata)
     <option value="{!! $cdata->id !!}">{!! $cdata->name !!}</option> 
   @endforeach
  @endif  
 </select>	
<div><a href="javascript:void(0)" id="restlocation">Reset location</a><input type="checkbox" name="map_show" id="map_show" value="y" class="show-map" checked>Show map on event page</div>   
</div>
 <div id="us3" style="width: 240px; height: 193px;">  </div>
</div>		  
 </div>
</div>
			<div class="form-group col-lg-12 col-sm-12 col-xs-12">
              <label class="col-lg-3 col-sm-3 col-xs-12 row"> <span class="require-val">*</span>Event Description: 
              </label>
              <div class="col-lg-9 col-sm-9 col-xs-12 send"> 
                  <textarea name="event_description" id="event_description" class="form-control ckeditor">{!!$edit_event[0]->event_description!!}</textarea>
				   {!! $errors->first('event_description', '<span class="help-block with-errors">:message</span>') !!}  
              </div>
            </div>		
  <?php $event_cost = $edit_event[0]->event_cost; ?>			
<div class="form-group col-lg-12 col-sm-12 col-xs-12">
              <label class="col-lg-3 col-sm-3 col-xs-12 row"> <span class="require-val">*</span>Cost: 
              </label>
              <div class="col-lg-6 col-sm-9 col-xs-12 send"> 
				 <input type="radio" name="event_cost" class="event_cost" value="free" @if(!empty($event_cost) && $event_cost == 'free') checked @else checked @endif/> Free Event  &nbsp; &nbsp;
                 <input type="radio" name="event_cost" class="event_cost" value="paid" @if(!empty($event_cost) && $event_cost == 'paid') checked @endif /> Paid 
				  {!! $errors->first('event_cost', '<span class="help-block with-errors">:message</span>') !!}                
             </div>
</div>		
<div class="form-group col-lg-12 col-sm-12 col-xs-12" id="event-price" @if(!empty($event_cost) && $event_cost == 'paid') style="display:block;" @else style="display:none;" @endif>	
   <label class="col-lg-3 col-sm-3 col-xs-12 row">Ticket Price: 
              </label>	
	<?php 
	 if(!empty($edit_event[0]->event_price)){
	   $ev_price = explode("-",$edit_event[0]->event_price);	
	 } else {
	   $ev_price = null;	 
	 }
    ?>	
  <div class="col-lg-6 col-sm-9 col-xs-12 send">
		   <label class="lab">
			  <span class="icon-prepend">$</span>
          <input name="event_price" id="event_price" value="{!!$ev_price[0]!!}" placeholder="Enter a single dollar amount" type="text" class="form-control"/>				 
		   <b>Flate Rate/Starting Amount</b>
		 </label> 
		  <label class="lab">
			  <span class="icon-prepend">$</span>			
        <input name="mevent_price" id="mevent_price" value="@if(isset($ev_price[1])){{$ev_price[1]}}@endif" placeholder="Enter a single dollar amount" type="text" class="form-control"/>				 			
		<b>Maximum Amount</b>
     </label>
			 <b>Example:</b> 10 or 10.99
				 {!! $errors->first('event_price', '<span class="help-block with-errors">:message</span>') !!} 				  
				 @if(!empty(Session::get('req_evprice')))
				 <span class="help-block with-errors">{{ Session::get('req_evprice') }}</span>
			    @endif  
 </div>
</div> 
	<div class="form-group col-lg-12 col-sm-12 col-xs-12" id="maintk_surl" @if(!empty($event_cost) && $event_cost == 'paid') style="display:block;" @else style="display:none;" @endif>
              <label class="col-lg-3 col-sm-3 col-xs-12 row"> <span class="require-val">*</span>Ticket Sales URL: 
              </label>
              <div class="col-lg-9 col-sm-9 col-xs-12 send url-link"> 
			  <label>
			   <!-- <span class="icon-prepend">{!!URL('ev/ticket/')!!}/</span>-->
                 <input name="ticket_surl" value="{!!$edit_event[0]->ticket_surl!!}" id="ticket_surl" type="text" class="form-control"/>				 
			  </label>
		 @if(!empty(Session::get('inv_tkurl')))
			<span class="help-block with-errors">{{ Session::get('inv_tkurl') }}</span>
		 @endif  			 
				 {!! $errors->first('ticket_surl', '<span class="help-block with-errors">The Ticket Sales URL field is required.</span>') !!} 
              </div>
    </div>
 <h4 class="event-head">  <span class="ico-box ico--small">2</span>Event Date(s)</h4>	
<div class="form-group col-lg-12 col-sm-12 col-xs-12">
			<div class="form-group col-lg-12 col-sm-12 col-xs-12">
			<div class="col-lg-12 col-sm-6 col-xs-12 row">
			 <label> <span class="require-val">*</span>Starts: </label>			
			  <div class="input-group date custom-dtime" id="datetimepicker2"> 
			   <?php
  			    if(!empty($edit_event[0]->event_date)){
				 $ev_date = date('m/d/Y', strtotime($edit_event[0]->event_date));
			    } else {
				 $ev_date = null;	
				}
			  ?>
                  <input type="text" name="sevent_date" class="form-control" value="{!!$ev_date!!}" required />
				  <span class="input-group-addon">
					<span class="glyphicon glyphicon-calendar"></span>
				  </span>
				 {!! $errors->first('sevent_date', '<span class="help-block with-errors">:message</span>') !!}  		 
              </div>
<div class="input-group date custom-dtime padd-n-xs">			 
<select class="time-set" name="sevent_time">
    <div class="ss">
	 @if(!empty($edit_event[0]->event_time))
	  <option value="{!!$edit_event[0]->event_time!!}" selected>{!!$edit_event[0]->event_time!!}</option>
	 @endif	
  @foreach($st_cvs as $scsv)
	@if(!empty($edit_event[0]->event_time))
	@if($edit_event[0]->event_time != $scsv)	
	 <option value="{!!$scsv!!}">{!!$scsv!!}</option> 
    @endif	
    @else
	 <option value="{!!$scsv!!}">{!!$scsv!!}</option> 	
	@endif		  
 @endforeach
</div>
</select>
 {!! $errors->first('sevent_time', '<span class="help-block with-errors">:message</span>') !!}   		 
</div> 			  
</div>		
			<div class="col-lg-12 col-sm-6 col-xs-12 row">
			 <label>Ends: &nbsp &nbsp </label>			
			  <?php
  			    if(!empty($edit_event[0]->end_date)){
				 $end_date = date('m/d/Y', strtotime($edit_event[0]->end_date));
			    } else {
				 $end_date = null;	
				}
			  ?>
			<div class="input-group date custom-dtime" id="datetimepicker3"> 
                  <input type="text" name="event_date" class="form-control" value="{!!$end_date!!}"/>
				  <span class="input-group-addon">
					<span class="glyphicon glyphicon-calendar"></span>
				  </span>
				 {!! $errors->first('event_date', '<span class="help-block with-errors">:message</span>') !!} 				 
              </div>
<div class="input-group date custom-dtime padd-n-xs">			 
<select class="time-set" name="eevent_time">
  @if(!empty($edit_event[0]->end_time))
   <option value="{!!$edit_event[0]->end_time!!}" selected>{!!$edit_event[0]->end_time!!}</option>
 @endif	
 @foreach($st_cvs as $scsv)
	@if(!empty($edit_event[0]->end_time))
	@if($edit_event[0]->end_time != $scsv)	
	 <option value="{!!$scsv!!}">{!!$scsv!!}</option> 
    @endif	
    @else
	 <option value="{!!$scsv!!}">{!!$scsv!!}</option> 	
	@endif		  
 @endforeach
</select>
 {!! $errors->first('eevent_time', '<span class="help-block with-errors">:message</span>') !!}   		 
</div> 			  
			</div>           
          </div>			  
      </div>
 <h4 class="event-head">  <span class="ico-box ico--small">3</span> Additional options</h4>
 <?php 
 if(!empty($edit_event[0]->fb_link) || !empty($edit_event[0]->tw_link)){
  $social_link = 'y';	 
 } else {
  $social_link = 'n';	 
 }
?>
  <div class="col-lg-12 col-sm-12 col-xs-12 rem-text">
   Social Media<br>
<input type="checkbox" name="social_link" id="social_link" value="y" @if(!empty($social_link) && $social_link == 'y') checked @endif />
    Include links to Facebook and Twitter 
</div>
<div class="col-lg-12 col-sm-12 col-xs-12" id="soc_url" @if(!empty($social_link) && $social_link == 'y') style="display:block;" @else style="display:none;" @endif>
<div>
<span class="fb"> </span> facebook.com/
<input type="text" name="fb_link" class="form-control mr-btm" value="{!! $edit_event[0]->fb_link !!}"/>
</div>
<div>
<span class="tw"> </span> twitter.com/ 
<input type="text" name="tw_link" class="form-control mr-btm" value="{!! $edit_event[0]->tw_link !!}"/>
</div>
</div> 
<h4 class="event-head">Listing Privacy</h4>	
<div class="col-lg-12 col-sm-12 col-xs-12 rem-text">
<input type="checkbox" class="pubprv" name="private_event" value="n" @if($edit_event[0]->private_event == 'n') checked @endif />
    Public Event</div>
<div class="col-lg-12 col-sm-12 col-xs-12 rem-text">
<input type="checkbox" class="pubprv" name="private_event" value="y" @if($edit_event[0]->private_event == 'y') checked @endif />
        Private Event <h6>(If check, Event will not be advertised to public. Only people you send the Event link to will have access to the Information)</h6>
</div>
{!! $errors->first('private_event', '<span class="help-block with-errors">Listing Privacy: Please select one option on here (Public/Private)</span>') !!} 
<h4 class="event-head">Event is:</h4>		
	<div class="col-lg-12 col-sm-12 col-xs-12 rem-text">
                      <input type="checkbox" id="option" name="available_purchase" value="y" @if($edit_event[0]->available_purchase == 'y') checked @endif />
                      Items/Products Available for Purchase</div>
						<div class="col-lg-12 col-sm-12 col-xs-12 rem-text">
                      <input type="checkbox" name="kid_event" value="y" @if($edit_event[0]->kid_event == 'y') checked @endif />
                      for Kids</div>
					  <div class="col-lg-12 col-sm-12 col-xs-12 rem-text">
                      <input type="checkbox" name="family_event" value="y" @if($edit_event[0]->family_event == 'y') checked @endif />
                      for Families</div>
					  <div class="col-lg-12 col-sm-12 col-xs-12 rem-text">
                      <input type="checkbox" name="religious_event" value="y" @if($edit_event[0]->religious_event == 'y') checked @endif />
                      a religious nature</div>			
			  <input type="hidden" name="_token" value="{{ csrf_token() }}">	    
		    <div class="form-group col-lg-12 col-sm-12 col-xs-12"> 
			  <input type="submit" class="form-control follow update-btn" Value="Update">
		    </div>
		 </form>  
        </div>
      </div>
 </section>
@stop
@section('scripts')
 <Script>
$(document).ready(function(){	
    $('#event_category').load('{!!URL("account/event-data/".$edit_event[0]->account_type."/".$edit_event[0]->event_type."/".$edit_event[0]->event_catid)!!}');
	  $("#event_description").cleditor({
		controls: 
            "bold italic underline | size " +
            "style | color | bullets numbering | outdent " +
            "indent | alignleft center alignright justify | undo redo | " +
            "rule | cut copy paste pastetext | source",
	  }); 	
	 jQuery("#event_url").keyup(function () {
      this.value = this.value.replace(/ /g, "_");
     });
	 
	 $('#datetimepicker2').datetimepicker({
      format: 'L'	
    });
	$('#datetimepicker3').datetimepicker({
      format: 'L'	
    });
 $('body').delegate(".event_category", 'change', function(){
   var secat = $( "select.event_category option:selected" ).text();
   var secat_url = secat.replace(/ /g, "_");
    $('#one_ours').load('{!!URL("account/event-img")!!}/'+secat_url);
 });
$('#one_ours').delay(4000).queue(function( vsnxt ) {	
   var vsxct = $( "select.event_category option:selected" ).text(); 	
   var vsxct_ul = vsxct.replace(/ /g, "_");
  $(this).load('{!!URL("account/event-img/")!!}/'+vsxct_ul);
 vsnxt();
});
   $("input#us3-address").blur(function(){	
	  $('#alloc_fileds').show(); 
	  $('#slocation').hide();
    });		
	$('body').delegate(".event_type", 'click', function(){
      var gradioValue = $("input[name='event_type']:checked").val();
	   $('#event_category').html('<img src="{!!URL::to("assets/public/default2/images/progress.gif")!!}" class="img-responsive" style="width:30px"/>');
     if(gradioValue){
        $('#event_category').load('{!!URL("account/event-data/".$edit_event[0]->account_type."/'+gradioValue+'/".$edit_event[0]->event_catid)!!}');
     }
    });
	$('body').delegate(".event_cost", 'click', function(){
      var ecradioValue = $("input[name='event_cost']:checked").val();
     if(ecradioValue){
	  if(ecradioValue == 'paid'){
	   $('#event-price').show();
	   $('#maintk_surl').show();	  
	  } else {
	   $('#event-price').hide();
	   $('#maintk_surl').hide();	  
	  }
     }
    });
	$('body').delegate("input[name='social_link']", 'click', function(){
      var soclink = $("input[name='social_link']:checked").val();
     if(soclink){
      $('#soc_url').show();
     } else {
	  $('#soc_url').hide();	
	 }
    });	
	$('.pubprv').click(function() {
     $('input.pubprv').not(this).prop('checked', false); 
    });
	$('#open_alldetail').click(function() {
     $('#alloc_fileds').show(); 
	  $('#slocation').hide();
    });
	$('#restlocation').click(function() {
     $('#alloc_fileds').hide(); 
	  $('#slocation').show();
	  $('#us3-address').val('');
	  $('#event_venue').val('');
	  $('#ev_address').val('');
	  $('#ev_addres').val('');
	  $('#evt_city').val('');
	  $('#evt_state').val('');
      $('#evt_zip').val('');		  
    });	
     function updateLvsControls(addressComponents) {
		$('#us3-venue').val(addressComponents.addressLine1);
		$('#evt_city').val(addressComponents.city);
		$('#evt_state').val(addressComponents.stateOrProvince);
		$('#evt_zip').val(addressComponents.postalCode);
		var countcode = addressComponents.country;
	if(countcode){	
     $.ajax({
        type: "GET",
        url: '{!!URL("cotryevnt")!!}/'+countcode,       
        beforeSend: function(){ 
          $('#us5-country').html('<option selected>loading</option>');
        },
        complete: function(){
        },
        success: function(data) {
         $('#us5-country').html(data);
        }
     });	
	}	 
    }
	 $('#us3').locationpicker({
        location: {latitude: 0, longitude: 0},
        radius: 1,
        inputBinding: {
            latitudeInput: $('#us3-lat'),
            longitudeInput: $('#us3-lon'),
            radiusInput: $('#us3-radius'),
            locationNameInput: $('#us3-address'),		
        },
        enableAutocomplete: true,
        onchanged: function (currentLocation, radius, isMarkerDropped) {
            var addressComponents = $(this).locationpicker('map').location.addressComponents;
           updateLvsControls(addressComponents);
        }
    });
	
	$("input#evt_state").blur(function(){
		var cyadd = $('input#evt_state').val();
		var cutryadd = $('#us5-country').find(":selected").text();
	 if(cutryadd){
	  var gsadd = cyadd+','+cutryadd;
	 } else {
	  var gsadd = cyadd;
	 }
       var geocoder =  new google.maps.Geocoder();
    geocoder.geocode( { 'address': gsadd}, function(results, status) {
        if(status == google.maps.GeocoderStatus.OK){
			 var latlong = results[0].geometry.location.lat();
			 var lnglong = results[0].geometry.location.lng();		 
	         var vsLatLng = {lat: latlong, lng: lnglong}
	     var map = new google.maps.Map(document.getElementById('us3'), {
                center: vsLatLng,
			    zoom: 6,
              });
         var marker = new google.maps.Marker({
             position: vsLatLng,
			 map: map,
			title: cyadd
           });	
       } else {
       }
      });
	}); 
	$("#us5-country").change(function(){
	 var cyadd = $('input#evt_state').val();
	 var cutryadd = $('#us5-country').find(":selected").text();	 
	 if(cyadd){
	  var gsadd = cyadd+','+cutryadd;
	  var vstitle = cyadd; 
	 } else {
	  var gsadd = cutryadd;
	  var vstitle = cutryadd;  
	 }	 
       var geocoder =  new google.maps.Geocoder();
    geocoder.geocode( { 'address': gsadd}, function(results, status) {
        if(status == google.maps.GeocoderStatus.OK){
			 var latlong = results[0].geometry.location.lat();
			 var lnglong = results[0].geometry.location.lng();		 
	         var vsLatLng = {lat: latlong, lng: lnglong}
	     var map = new google.maps.Map(document.getElementById('us3'), {
                center: vsLatLng,
			    zoom: 6,
              });			 
         var marker = new google.maps.Marker({
             position: vsLatLng,
			 map: map,
			title: vstitle
           });	
       }
      });
 });
  $('body').delegate("a.ourimg_tag", 'click', function(){
    var src= $(this).find('img').attr('src');
	$('#sel_ourimg').html('<div class="jFiler-item-thumb-image"><img draggable="false" src="'+src+'"/></div>'); 	
	$('#sel_ourimg').css("display", "block");
    $( "#csimg" ).trigger( "click" );
  });	
});
 function selimg(imgid){
  $("#our_pid").val(imgid); 	
 }
 </script> 
 @if(!empty($all_address))
	 <script> 
	   $(document).ready(function(){	   
		$( "#open_alldetail" ).trigger( "click" );  
		 var geocoder = new google.maps.Geocoder();
		geocoder.geocode( {'address': '{!! $all_address !!}'}, function(results, status) {
			if(status == google.maps.GeocoderStatus.OK){
				 var latlong = results[0].geometry.location.lat();
				 var lnglong = results[0].geometry.location.lng();		 
				 var vsLatLng = {lat: latlong, lng: lnglong}
			 var map = new google.maps.Map(document.getElementById('us3'), {
					center: vsLatLng,
					zoom: 6,
				  });			 
			 var marker = new google.maps.Marker({
				 position: vsLatLng,
				 map: map,
				title: '{!! $all_address !!}'
			   });	
		   }
		  });		
	  });	
	 </script>
 @endif 
@stop