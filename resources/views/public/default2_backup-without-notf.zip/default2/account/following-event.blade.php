@extends('public/default2/_layouts._layout')
@section('styles')    
@stop
@section('content')
<section class="sec">
<div class="tabbable tabs-left">
        @include("public/default2/_layouts._AccountMenu")
        <div class="tab-content">
         <div class="tab-pane active">
		 
		    
				 @if(Session::has('succ_mesg'))
                <span class="col-md-12 full-success alert">
                  <button data-dismiss="alert" aria-label="close" class="close">&times;</button>
                  <strong>Success!</strong> {!! Session::get('succ_mesg') !!}
                </span>			
             @endif
			
	<div class="form-group col-lg-12 col-sm-8 col-xs-12 table-responsive" id="content">	
	
	  <h3 class="mr-botom25"> Following </h3>
	
	
	
     @if(!empty($follow_acc[0]->id))		
      <table class="table table-striped padd">
       <thead>	
        <tr>
         <th>Page Name</th>
         <th>Page Picture</th>
		 <th>Email</th>	
         <th>Page Website URL</th>			 
		 <th>Operation</th>
        </tr>
       </thead>
       <tbody>
	    @foreach($follow_acc as $fllacc)
	     <tr>
          <td>{!! ucfirst($fllacc->name) !!}</td>
          <td>
		   @if(!empty($fllacc->upload_file))
			<?php 
			 if($fllacc->g_id == 2) {
				 $cimg_apath = 'business';
			 } elseif($fllacc->g_id == 5) { 
				 $cimg_apath = 'municipality';
			 } else {
				 $cimg_apath = 'club';
			 }		 
			?>
		    <img src="{!!URL::to('uploads/account_type/'.$cimg_apath.'/'.$fllacc->upload_file)!!}" class="img-responsive" style="width:35px"/>
	       @else
		    n/a 
		   @endif	 
		  </td>
          <td>{!! $fllacc->email !!}</td>
		  <?php $event_detailsstr = preg_replace('#^https?://#', '', $fllacc->website); ?>
		  <td><a href="{!! $fllacc->website !!}" target="_blank"> {!! $event_detailsstr !!} </a></td>
          <td>
<a href='javascript:void(0)' onClick="window.open('{!!URL($fllacc->account_url)!!}','_blank','scrollbars=1,width=1000,height=600'); return false;" class="btn btn-inverse btn-xs">View</a>
		   <a href="{!!$fllacc->id!!}" class="btn btn-primary btn-xs">Unfollow page</a>
		  </td>
         </tr>         
        @endforeach         
       </tbody>
      </table>
	   {!! $follow_acc->render() !!}
     @else
	   empty...
     @endif		
   </div>			
  </div>      
 </div>
</div>
</section>
@stop
@section('scripts')
@stop