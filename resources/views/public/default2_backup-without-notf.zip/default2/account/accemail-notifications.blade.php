@extends('public/default2/_layouts._layout')
@section('styles')    
@stop
@section('content')
 <section class="sec">
      <div class="tabbable tabs-left">
       @include("public/default2/_layouts._AccountMenu")
        <div class="tab-content">
         <div class="tab-pane active">		 
		  <b>Account name:</b> {{ $event_details[0]->name }}
		 <h3> Email Notifications </h3>
		    <form class="form-inline" method="post" action="" enctype="multipart/form-data"> 
			  <img src="{!!URL::to('assets/public/default2/images/coming-soon.jpg')!!}"/>
			</form>
		</div>      
        </div>
      </div>
</section>
@stop
@section('scripts')
@stop