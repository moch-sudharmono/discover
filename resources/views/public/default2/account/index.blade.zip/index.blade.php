@extends('public/default2/_layouts._layout')
@section('styles') 
   
@stop
@section('content')
 <section class="sec">
    <!-- left nav -bar -->
      <!-- tabs left -->
      <div class="tabbable tabs-left">
        <ul class="nav nav-tabs">
          <li><a href="#account" data-toggle="tab">Account Details </a></li>
          <li class="active"><a href="#createEvent" class="ac-cevent" data-toggle="tab">Create Event </a></li>
          <li><a href="#manageEvent" data-toggle="tab" class="ac-mevent">Manage Event </a></li>
		  <li><a href="#notifications " data-toggle="tab" class="ac-notf">Email Notifications  </a></li>
		  <li><a href="#following" data-toggle="tab" class="ac-follow">Following   </a></li>
		  <li><a href="#payment" data-toggle="tab">Payment </a></li>
        </ul>
        <div class="tab-content">
         <div class="tab-pane active" id="account">
		 <h3> Heading will come here </h3>
		 Lorem ipsum dolor sit amet, charetra varius quam sit amet vulputate. 
         Quisque mauris augue, molestie tincidunt condimentum vitae, gravida a libero.</div>
		 
         <div class="tab-pane" id="createEvent">
		  <h3> Heading will come here </h3>
		  Secondo sed ac orci quis tortor imperdiet venenatis. Duis elementum auctor accumsan. 
         Aliquam in felis sit amet augue.</div>
		 
         <div class="tab-pane" id="manageEvent">
		  <h3> Heading will come here </h3>
		  Thirdamuno, ipsum dolor sit amet, consectetur adipiscing elit. Duis pharetra varius quam sit amet vulputate. 
         Quisque mauris augue, molestie tincidunt condimentum vitae. </div>
		  <div class="tab-pane" id="notifications">   </div>
		  <div class="tab-pane" id="following">
		  <h3> Heading will come here </h3>
		  Thirdamuno, ipsum dolor sit amet, consectetur adipiscing elit. Duis pharetra varius quam sit amet vulputate. 
         Quisque mauris augue, molestie tincidunt condimentum vitae.
		 </div>
        </div>
      </div>
      <!-- /tabs -->
    <!-- /left nav bar end --> 	
  </div>
  </div>
</section>
<!--
1.3.3.2.	Create Event (discoveryourevent.com/account/createEvent)
1.3.3.3.	Manage Event (discoveryourevent.com/account/manageEvent)
1.3.3.4.	EmailNotifications (discoveryourevent.com/account/notifications 
1.3.3.5.	Following (discoveryourevent.com/account/following
1.3.3.6.	Payment (discoveryourevent.com/account/payment) 
-->
@stop
@section('scripts')
<script>
 $( "#createEvent" ).html( '<img class="img-responsive img-progress" src="{!!URL::to("assets/public/default2/images/progress.gif")!!}"/>' );
 $( "#manageEvent" ).html( '<img class="img-responsive img-progress" src="{!!URL::to("assets/public/default2/images/progress.gif")!!}"/>' );
 $( "#notifications" ).html( '<img class="img-responsive img-progress" src="{!!URL::to("assets/public/default2/images/progress.gif")!!}"/>' );
 $( "#following" ).html( '<img class="img-responsive img-progress" src="{!!URL::to("assets/public/default2/images/progress.gif")!!}"/>' );
  $('.ac-cevent').click(function() { 
  $( "#createEvent" ).load( '{!!URL("account/createEvent")!!}' );
 });
 $('.ac-mevent').click(function() { 
  $( "#manageEvent" ).load( '{!!URL("account/manageEvent")!!}' );
 });

 $('.ac-notf').click(function() { 
  $( "#notifications" ).load( '{!!URL("account/notifications")!!}' );
 });
 
 $('.ac-follow').click(function() { 
  $( "#following" ).load( '{!!URL("account/following")!!}' );
 });
</script>
@stop