<?php
/*
=================================================
CMS Name  :  DOPTOR
CMS Version :  v1.2
Available at :  www.doptor.org
Copyright : Copyright (coffee) 2011 - 2015 Doptor. All rights reserved.
License : GNU/GPL, visit LICENSE.txt
Description :  Doptor is Opensource CMS.
===================================================
*/
use Modules\Doptor\Slideshow\Models\Slideshow;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;

 class NovComet {
    const COMET_OK = 0;
    const COMET_CHANGED = 1;
    private $_tries;
    private $_var;
    private $_sleep;
    private $_ids = array();
    private $_callback = null;
    public function  __construct($tries = 10, $sleep = 2) 
    {
        $this->_tries = $tries;
        $this->_sleep = $sleep;
    }

    public function setVar($key, $value)
    {
        $this->_vars[$key] = $value;
    }
    
    public function setTries($tries)
    {
        $this->_tries = $tries;
    }
   
    public function setSleepTime($sleep)
    {
        $this->_sleep = $sleep;
    }
    
    public function setCallbackCheck($callback)
    {
        $this->_callback = $callback;
    }
	
    const DEFAULT_COMET_PATH =  "customAlert.comet";  
	
    public function run($lg_id){
      $notfresult = DB::table('notifications')->where('onr_id', '=', $lg_id)->where('global_read', '=', 0)->select('id')->get();   
     if(is_null($this->_callback)){
       $defaultCometPAth =  asset(self::DEFAULT_COMET_PATH);	  
       $callback = function($id) use ($defaultCometPAth) {
         $cometFile = sprintf($defaultCometPAth, $id);				
        return (is_file($cometFile)) ? filemtime($cometFile) : 0;
       };
     } else {
        $callback = $this->_callback;
     }
      $out = array();
	 if(!empty($notfresult[0]->id)){       		 
        for($i = 0; $i < $this->_tries; $i++){
		  $p = 0;
         foreach($this->_vars as $id => $timestamp){
            if((integer) $timestamp == 0){
                    $timestamp = time();
            }
             $fileTimestamp = $callback($id);
            if($fileTimestamp > $timestamp){
                    $out[$id] = $fileTimestamp;
            }
           clearstatcache();
         }	
		
		foreach($notfresult as $getnid){
		 if($p == 0){			
		  $notfid = $getnid->id; 
		 } else {		  
		  $notfid .= ','.$getnid->id;	 
		 }	
		  $p++;
		}	
         if(count($out) > 0){				
          return json_encode(array('s' => self::COMET_CHANGED, 'k' => $out, 'ncount' => sizeof($notfresult), 'ncd' => $notfid));
         }
          sleep($this->_sleep);
        }
	   return json_encode(array('s' => self::COMET_OK, 'ncount' => sizeof($notfresult), 'ncd' => $notfid));	
	 } else { 
	  return json_encode(array('s' => 0, 'ncount' => 0, 'ncd' => 0));		 
	 }	   
    }
 }

class HomeController extends BaseController {
	
	public function index()
	{ 
		//$get_groupid = DB::table('users_groups')->where('user_id', '=', $lg_id)->select('group_id')->get();		
      $page = Post::where('permalink', '=', 'welcome')->first();
       // $slides = Slideshow::latest()->get();
	  $this->layout->title = 'Welcome To DiscoverYourEvents';
	  $cdate = date('Y-m-d');
	 if(Sentry::check()){		
		 Session::forget('selaccount'); 
		 $lg_id = Sentry::getUser()->id;     
	 /* $all_events = DB::table('events')->where('private_event', '!=', 'y')->select('id','event_name','account_id','account_type','event_url','event_image','event_venue',
	  'event_address','country','event_date','event_time','event_cost','event_price')->orderBy('id', 'desc')->paginate(8);	  */
	$all_events = DB::table('events')->where('private_event', '!=', 'y')->select('id','event_name','account_id','account_type','event_url','event_image','event_venue',
	  'event_address','country','event_date','event_time','event_cost','event_price')->orderBy('id', 'desc')->paginate(8);
//$fromDate = Carbon\Carbon::now()->subDay()->startOfWeek()->toDateString(); // or ->format(..)
//$tillDate = Carbon\Carbon::now()->subDay()->toDateString();
//var_dump($fromDate);	  
	 $attend_event = DB::table('users_events')->where('users_events.u_id', '=', $lg_id)->join('events', 'users_events.e_id', '=', 'events.id')
	  ->select('events.id','events.event_name','events.account_id','events.account_type','events.event_url','events.event_image','events.event_venue','events.event_address',
	  'events.event_date','events.event_time','events.event_cost','events.event_price')->orderBy('event_name', 'ASC')->get();
	  /* $my_events = DB::table('events')->where('u_id', '=', $lg_id)->select('id','event_name','account_type','event_url','event_image','event_venue',
	  'event_address','event_date','event_time','event_cost','event_price')->get();
	  $follow_events = DB::table('user_follows')->where('user_follows.u_id', '=', $lg_id)
	    ->join('events', 'user_follows.follow_id', '=', 'events.account_id')
	   ->select('events.id','user_follows.id as ufid','events.event_name','events.account_type','events.event_url','events.event_image','events.event_venue',
	  'events.event_address','events.event_date','events.event_time','events.event_cost','events.event_price')->get();	*/
	  $fl_acc = DB::table('user_follows')->where('user_follows.u_id', '=', $lg_id)->where('user_follows.follow', '=', 'y')
	  ->join('account_details', 'user_follows.follow_id', '=', 'account_details.id')->distinct('user_follows.follow_id')
	  ->select('user_follows.id', 'account_details.name', 'account_details.account_url')->orderBy('account_details.name', 'ASC')->get();	

	 $unfl_acc = DB::table('account_details')->where('account_details.u_id', '!=', $lg_id)
	  ->select('account_details.id', 'account_details.name', 'account_details.account_url')->orderBy('account_details.name', 'ASC')->get();
	  
	  $event_data = DB::table('event_data')->distinct('event_data.event_category')->select('event_data.event_category')->get();	
	 foreach($event_data as $obj_arr ){
	  $et_dt[] = $obj_arr->event_category; 
	 } 
       $evtsdata = array_unique($et_dt);	    
	   $home_blade = 'index_login';	
	  //  $this->layout->content = View::make('public.'.$this->current_theme.'.'.$home_blade)->with('page', $page)->with('attend_event', $attend_event)->with('my_evnt', $my_events)
	  //->with('al_event', $all_events)->with('clid', $lg_id)->with('fl_event', $follow_events)->with('fl_acc', $fl_acc);
	$uaccount_dts = DB::table('group_details')->where('u_id','=', $lg_id)->select('address','city','state','country','zip_code')->get();
 $full_event = DB::table('events')->where('events.private_event', '!=', 'y')->select('id','event_name','event_url','event_image','event_venue',
	  'event_address','address_secd','city','state','country')->get();	
	  //->where('event_date', '>=', $cdate)
/***************main-map*************************/
   $all_address = null; 
    /*  if(!empty($uaccount_dts[0]->address)){
	   $all_address .= $uaccount_dts[0]->address;
      }	*/ 
    if(!empty($uaccount_dts[0]->city)){
		$getcdata = DB::table('cities')->where('id', '=', $uaccount_dts[0]->city)->select('id','name')->get();		
     if(!empty($getcdata[0]->id)){
  	  if(!empty($all_address)){		 	  
	    $all_address .= ','.$getcdata[0]->name;  
	  } else {
		$all_address = $getcdata[0]->name;   
	  }
     }
    }  
 if(!empty($uaccount_dts[0]->state)){ 
  $getsdata = DB::table('states')->where('id', '=', $uaccount_dts[0]->state)->select('id','name')->get();
  if(!empty($getsdata[0]->id)){
	 if(!empty($all_address)){		 	  
	    $all_address .= ','.$getsdata[0]->name;  
	   } else {
		$all_address = $getsdata[0]->name;   
	   }	   
	  $rsearch_detail = $getsdata[0]->name; 
  } 
 } 
 if(!empty($uaccount_dts[0]->country)){
	   $getcydata = DB::table('countries')->where('id', '=', $uaccount_dts[0]->country)->select('id','name')->get(); 
   if(!empty($getcydata[0]->id)){
	   if(!empty($all_address)){		 	  
	    $all_address .= ','.$getcydata[0]->name;  
	   } else {
		$all_address = $getcydata[0]->name;   
	   }
	   
	   $ucuntry = $getcydata[0]->name; 
   } 
 }

if(!empty($full_event[0]->id)){
 $xx = 1; foreach($full_event as $flce){     
  $lfalc_add = null; 
      if(!empty($flce->event_venue)){
	   $lfalc_add .= $flce->event_venue;
      }			  
	  if(!empty($flce->event_address)){
	   if(!empty($lfalc_add)){		 	  
	    $lfalc_add .= ','.$flce->event_address;  
	   } else {
		$lfalc_add = $flce->event_address;   
	   }
      }	
     if(!empty($flce->address_secd)){
	   if(!empty($lfalc_add)){		 	  
	    $lfalc_add .= ','.$flce->address_secd;  
	   } else {
		$lfalc_add = $flce->address_secd;   
	   }
      }	
     if(!empty($flce->city)){
	   if(!empty($lfalc_add)){		 	  
	    $lfalc_add .= ','.$flce->city;  
	   } else {
		$lfalc_add = $flce->city;   
	   }
      }	
	  
 if(!empty($flce->state) && !empty($flce->country)){ 
  $getssdata = DB::table('states')->where('country_id', '=', $flce->country)->where('name', '=', $flce->state)->select('id','name')->get();
  if(!empty($getssdata[0]->id)){
	$staten = $getssdata[0]->name;
  } else {
	$staten = $flce->state;
  }
    if(!empty($staten)){
	   if(!empty($lfalc_add)){		 	  
	    $lfalc_add .= ','.$staten;  
	   } else {
		$lfalc_add = $staten;   
	   }
   }
 }
 if(!empty($flce->country)){
	 $getccdata = DB::table('countries')->where('id', '=', $flce->country)->select('id','name')->get(); 
	 if(!empty($getccdata[0]->id)){
	   if(!empty($lfalc_add)){		 	  
	    $lfalc_add .= ','.$getccdata[0]->name;  
	   } else {
		$lfalc_add = $getccdata[0]->name;   
	   }
	 } 
   } 
   $maddressArray[] = $lfalc_add; 
   $morgTitleArray[] = $flce->event_name;
   $morg_surlArray[] = $flce->event_url;
   $xx++;
  } 
} else {
 $maddressArray = null;	
 $morgTitleArray = null;
 $morg_surlArray = null;
} 
/********************end-mmap**************/    
 $u_upcevent = DB::table('events')->where('u_id', '=', $lg_id)->where('private_event', '!=', 'y')->select('id','event_name','event_url','event_image','event_venue',
	  'event_address','address_secd','city','state','country','event_date','end_date')->get(); //->where('event_date', '>=', $cdate)
/************************left-map***************************/
if(!empty($u_upcevent[0]->id)){
 $x = 1; foreach($u_upcevent as $uce){     
  $lfal_add = null; 
      if(!empty($uce->event_venue)){
	   $lfal_add .= $uce->event_venue;
      }			  
	  if(!empty($uce->event_address)){
	   if(!empty($lfal_add)){		 	  
	    $lfal_add .= ','.$uce->event_address;  
	   } else {
		$lfal_add = $uce->event_address;   
	   }
      }	
     if(!empty($uce->address_secd)){
	   if(!empty($lfal_add)){		 	  
	    $lfal_add .= ','.$uce->address_secd;  
	   } else {
		$lfal_add = $uce->address_secd;   
	   }
      }	
     if(!empty($uce->city)){
	   if(!empty($lfal_add)){		 	  
	    $lfal_add .= ','.$uce->city;  
	   } else {
		$lfal_add = $uce->city;   
	   }
      }	
	  
 if(!empty($uce->state) && !empty($uce->country)){ 
  $getsssdata = DB::table('states')->where('country_id', '=', $uce->country)->where('name', '=', $uce->state)->select('id','name')->get();
  if(!empty($getsssdata[0]->id)){
	$staten = $getsssdata[0]->name;
  } else {
	$staten = $uce->state;
  }
    if(!empty($staten)){
	   if(!empty($lfal_add)){		 	  
	    $lfal_add .= ','.$staten;  
	   } else {
		$lfal_add = $staten;   
	   }
   }
 }
 if(!empty($uce->country)){
	 $getcccdata = DB::table('countries')->where('id', '=', $uce->country)->select('id','name')->get(); 
    if(!empty($getcccdata[0]->id)){ 	  
	  if(!empty($lfal_add)){		 	  
	    $lfal_add .= ','.$getcccdata[0]->name;  
	   } else {
		$lfal_add = $getcccdata[0]->name;   
	   }
	}   
   }  
   //$addressArray[] = "['".$lfal_add."'],"; 
   $addressArray[] = $lfal_add; 
   $orgTitleArray[] = $uce->event_name;
   $org_surlArray[] = $uce->event_url;
   $x++;
  } 
} else {
 $addressArray = null;	
 $orgTitleArray = null;
 $org_surlArray = null;
} 
/***********************end-lmap*****************************/
    $this->layout->content = View::make('public.'.$this->current_theme.'.'.$home_blade)->with('page', $page)->with('attend_event', $attend_event)->with('al_event', $all_events)
	 ->with('clid', $lg_id)->with('fl_acc', $fl_acc)->with('unfl_acc',$unfl_acc)->with('evtsdata', $evtsdata)
	 ->with('all_address',$all_address)->with('upcevnt',$u_upcevent)->with('addressArray', $addressArray)->with('ucuntry',$ucuntry)->with('rsearch_detail',$rsearch_detail)
	 ->with('orgTitleArray',$orgTitleArray)->with('org_surlArray',$org_surlArray)->with('full_event',$full_event)
	 ->with('maarray', $maddressArray)->with('mTiAr',$morgTitleArray)->with('mog_slar',$morg_surlArray);   
   } else { 
	  $all_events = DB::table('events')->where('private_event', '!=', 'y')->select('id','event_name','account_id','account_type','event_url','event_image','event_venue','country',
	  'event_date','event_cost','event_price')->orderBy('id', 'desc')->paginate(8);
	  $event_data = DB::table('event_data')->distinct('event_data.event_category')->select('event_data.event_category')->get();	
	  foreach($event_data as $obj_arr ){
	   $et_dt[] = $obj_arr->event_category; 
	  }
       $evtsdata = array_unique($et_dt);
	   $home_blade = 'index';
	   $this->layout->content = View::make('public.'.$this->current_theme.'.'.$home_blade)->with('page', $page)->with('al_event', $all_events)->with('evtsdata', $evtsdata); 
     } //->with('slides', $slides)	        
	}
	
	public function postClocation(Request $request)
    {
		 $data = $request->input();
		if(!empty($data['curlocation'])){
		  $lat_long = $data['curlocation']; 
		 $url = "http://maps.googleapis.com/maps/api/geocode/json?latlng=".$lat_long."&sensor=false";
			// Make the HTTP request
			$data = @file_get_contents($url);
			// Parse the json response
			$jsondata = json_decode($data,true);	
			function check_status($jsondata) {
			 if ($jsondata["status"] == "OK") return true;
			 return false;
			}	
			// If the json data is invalid, return empty array
			if (!check_status($jsondata))	return array();		
			//$LatLng = $jsondata["results"][0]["formatted_address"];
			$LatLng = $jsondata["results"][0]['address_components'];
		  $current_add = null;	
		  $sca = null;
		  foreach($LatLng as $add_comp){
			if($add_comp['types'][0] == 'administrative_area_level_2'){	
			 $current_add .= $add_comp['long_name'];
			// $sca .= $add_comp['short_name'];
			}	
			if($add_comp['types'][0] == 'administrative_area_level_1'){	
			 $sca .= $add_comp['short_name'];
			  if(!empty($current_add)){	
			   $current_add .= ', '.$add_comp['long_name'];		   
			  }	else {				
			   $current_add .= $add_comp['long_name']; 	   
			  } 
			 }		
			 if($add_comp['types'][0] == 'country'){
			  if(!empty($current_add)){				
			  // $current_add .= ', '.$add_comp['long_name'];  
				$sca .= ', '.$add_comp['short_name']; 				   
			  }	else {				
			   //$current_add .= $add_comp['long_name']; 
               $sca .= $add_comp['short_name']; 			   
			  } 
			 }
		  }
		  return $current_add.'~'.$sca;
		  die;
		}
	}	
	
	 public function getImglocation($latlong)
    {
	 if(!empty($latlong)){ 
		$url = "http://maps.googleapis.com/maps/api/geocode/json?latlng=".$latlong."&sensor=false";
		$data = @file_get_contents($url);
		$jsondata = json_decode($data,true);	
		function check_status($jsondata) {
		  if ($jsondata["status"] == "OK") return true;
		 return false;
		}	
		if (!check_status($jsondata))	return array();		
		  $LatLng = $jsondata["results"][0]['address_components'];
		 foreach($LatLng as $add_comp){
		  if($add_comp['types'][0] == 'administrative_area_level_1'){	
			$simg = strtolower($add_comp['short_name']);
		  }		
		  if($add_comp['types'][0] == 'country'){
			 $cimg = strtolower($add_comp['short_name']); 
		  }
		 }
       $home_sdata = DB::table('home_slide')->where('country_code', '=', $cimg)->where('city_name', '=', $simg)->get(); 		 
		// 'uploads/city_photos/'.$cimg.'ca_ab.jpg';
	  if(!empty($home_sdata[0]->id)){
		$xx = 0;
	   foreach($home_sdata as $hsd){		   
		$hs_img = asset("uploads/city_photos/".$hsd->country_code."/".$hsd->image);   
	    if($xx == 0){	
		 echo '<li style="background-image: url('.$hs_img.'); opacity: 1;"><img id="default-'.$hsd->id.'" src="'.$hs_img.'"></li>';  
  		} else {
		 echo '<li style="opacity: 0;"><img id="default-'.$hsd->id.'" src="'.$hs_img.'"></li>';  	
		}
		$xx++;
	   }	  
	  } else {
         $vdefault = array('ca_ab.jpg','ca_on_ottawa.jpg','ca_on_toronto.jpg','us_ca_la.jpg','us_ct.jpg','us_nv_vegas.jpg');
		$x = 0;
	   foreach($vdefault as $vdf){
		$burl = asset('uploads/city_photos/'.$vdf); 
		if($x == 0){
		 echo '<li style="background-image: url('.$burl.'); opacity: 1;"><img id="default-'.$x.'" src="'.$burl.'"></li>'; 	
		} else {
		 echo '<li style="opacity: 0;"><img id="default-'.$x.'" src="'.$burl.'"></li>'; 	
		}		   
		$x++;
	   }	  
	  }
	  die;
	 }
	}
	
 public function globalComet($dyetimestamp){ 
  if(Sentry::check()){		
   $lg_id = Sentry::getUser()->id;   	 
   $dtstamp = explode("&",$dyetimestamp);
   if(!empty($dtstamp[0])){
	$comet = new NovComet();   
     $comet->setVar('notificationAlert', $dtstamp[0]);
    echo $comet->run($lg_id);
   }
  }   
  die;
 }
 
  public function globalNotification($ids){ 
  if(Sentry::check() && !empty($ids)){		
   $lg_id = Sentry::getUser()->id;  
    $dataid = explode(",",$ids);
  if(!empty($dataid[0])){
	    $xs = 0; 
	foreach($dataid as $dsid){ //->where('id', '=', $dsid)
     $notfdata = DB::table('notifications')->where('onr_id', '=', $lg_id)->where('is_read', '=', 0)->orderBy('id', 'desc')->take(5)->get(); 
        if(!empty($notfdata[0]->id)){		 	  
		 foreach($notfdata as $nd){
          if($nd->global_read == 1){
		   $rd_stats = 'notif-acc'; 
		  } else {
		   $rd_stats = 'notif-acc active';
		  } 			 
		   if($nd->type == 'event'){		 
	         $evntlu = DB::table('events')->where('id', '=', $nd->object_id)->select('event_url')->get(); 	
             $nldurl = url("/event/".$evntlu[0]->event_url); 			 
			if($xs == 0){
			  $arvs = '<li id="notf-'.$nd->id.'"><div class="'.$rd_stats.'"><a href="'.$nldurl.'">'.$nd->subject.'</a>
			  <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$nd->id.');"><span class="fa fa-times"></span></a></div></li>';	
			} else {
			  $arvs .= '<li id="notf-'.$nd->id.'"><div class="'.$rd_stats.'"><a href="'.$nldurl.'">'.$nd->subject.'</a>
			  <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$nd->id.');"><span class="fa fa-times"></span></a></div></li>';	
			}
		   } else if($nd->type == 'page'){
			  $evntlu = DB::table('account_details')->where('id', '=', $nd->object_id)->select('account_url')->get(); 
			  $nldurl = url("/".$evntlu[0]->account_url); 				
			if($xs == 0){
			  $arvs = '<li id="notf-'.$nd->id.'"><div class="'.$rd_stats.'"><a href="'.$nldurl.'">'.$nd->subject.'</a>
			  <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$nd->id.');"><span class="fa fa-times"></span></a></div></li>';	
			} else {
			  $arvs .= '<li id="notf-'.$nd->id.'"><div class="'.$rd_stats.'"><a href="'.$nldurl.'">'.$nd->subject.'</a>
			  <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$nd->id.');"><span class="fa fa-times"></span></a></div></li>';	
			}	
		   } else {
			if($xs == 0){
			  $arvs = '<li id="notf-'.$nd->id.'"><div class="'.$rd_stats.'"><a href="#">'.$nd->subject.'</a>
			  <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$nd->id.');"><span class="fa fa-times"></span></a></div></li>';	
			} else {
			  $arvs .= '<li id="notf-'.$nd->id.'"><div class="'.$rd_stats.'"><a href="#">'.$nd->subject.'</a>
			  <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$nd->id.');"><span class="fa fa-times"></span></a></div></li>';	
			}				
		   }
		 $xs++;	
		 }	  
	    }   	 
    }	 
  } else { //->where('id', '=', $dsid)
	$notfdata = DB::table('notifications')->where('onr_id', '=', $lg_id)->where('is_read', '=', 0)->orderBy('id', 'desc')->take(5)->get();  
     if(!empty($notfdata[0]->id)){
		 if($notfdata[0]->global_read == 1){
		   $rd_stats = 'notif-acc'; 
		  } else {
		   $rd_stats = 'notif-acc active';
		  } 
	  if($notfdata[0]->type == 'event'){		 
	    $evntlu = DB::table('events')->where('id', '=', $notfdata[0]->object_id)->select('event_url')->get(); 	
        $nldurl = url("/event/".$evntlu[0]->event_url); 
	   $arvs = '<li id="notf-'.$notfdata[0]->id.'"><div class="'.$rd_stats.'"><a href="'.$nldurl.'">'.$notfdata[0]->subject.'</a>
	   <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$notfdata[0]->id.');"><span class="fa fa-times"></span></a></div></li>';			
	  } else if($notfdata[0]->type == 'page'){
		 $evntlu = DB::table('account_details')->where('id', '=', $notfdata[0]->object_id)->select('account_url')->get(); 
		 $nldurl = url("/".$evntlu[0]->account_url); 	
	   $arvs = '<li id="notf-'.$notfdata[0]->id.'"><div class="'.$rd_stats.'"><a href="'.$nldurl.'">'.$notfdata[0]->subject.'</a>
	   <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$notfdata[0]->id.');"><span class="fa fa-times"></span></a></div></li>';	 
      } else {
	   $arvs = '<li id="notf-'.$notfdata[0]->id.'"><div class="'.$rd_stats.'"><a href="#">'.$notfdata[0]->subject.'</a>
	    <a class="notf-close" href="javascript:void(0)" onClick="sRead('.$notfdata[0]->id.');"><span class="fa fa-times"></span></a></div></li>';		 
	  }			
	 }
  }
     $anct = DB::table('notifications')->where('onr_id', '=', $lg_id)->where('is_read', '=', 0)->count();   
	if(isset($anct)){
	 $acvs = $anct;	
	} else {
	 $acvs = 0;	
	} 
   if(isset($arvs)){
	return array('nlist' => $arvs,'ncount' => $acvs);   //json_encode(array('n' => $ids, 'svdata' => $arvs));	
   } else {
	return 0;   
   }  
  }   
  die;
 }
  public function readNotification($ids){ 
    if(Sentry::check() && !empty($ids)){	
     $lg_id = Sentry::getUser()->id; 
      DB::delete('delete from notifications WHERE id = '.$ids.' && onr_id = '.$lg_id); 
	  return 1;
    }
	return 2;
   die;
  }
  
  public function globalRdNotif($counts){ 
   if(Sentry::check() && !empty($counts)){	
     $lg_id = Sentry::getUser()->id; 
	 $notfdata = DB::table('notifications')->where('onr_id', '=', $lg_id)->where('global_read', '=', 0)->orderBy('id', 'desc')->take($counts)->select('id')->get();  
   if(!empty($notfdata[0]->id)){
	foreach($notfdata as $ntfd){
	 DB::table('notifications')->where('id', '=', $ntfd->id)->update(['global_read' => 1,'updated_at' => date('Y-m-d H:i:s')]);
    }   
   }
    return 1;
   }
	 return 2;
    die;
  }
  

    public function wrapper($menu_id)
    {
        $menu = Menu::findOrFail($menu_id);
        $this->layout->title = $menu->title;
        $this->layout->content = View::make('public.'.$this->current_theme.'.wrapper')
                                        ->with('menu', $menu);
    }

    public function getContact()
    {
        $contact = Post::type('page')
                            ->where('permalink', 'contact')
                            ->first();

        $this->layout->title = 'Contact Us';

        $this->layout->content = View::make('public.'.$this->current_theme.'.contact')
                                        ->with('contact', $contact);
    }

    public function postContact()
    {
        $input = Input::all();

        $rules = array(
                'email' => 'required|min:5|email',
                'name' => 'required|alpha|min:5',
            );

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::back()
                                ->withErrors($validator)
                                ->withInput();
        }

        try {
            Mail::send('public.'.$this->current_theme.'.email', $input, function($message) use($input) {
              $message->from($input['email'], $input['name']);
              $message->to(Setting::value('email_username'), $input['name'])
                        ->subject($input['subject']);
            });
        } catch (Exception $e) {
            return Redirect::back()
                                ->withInput()
                                ->with('error_message', $e->getMessage());
        }

        return Redirect::back()
                            ->with('success_message', 'The mail was sent.');
    }
}