<?php 
use Services\UserManager;
use Services\UserGroupManager;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;


class AccountController extends Controller {
	
    protected $user_manager;
    protected $usergroup_manager;

    public function __construct(UserManager $user_manager, UserGroupManager $usergroup_manager)
    {
        $this->user_manager = $user_manager;
        $this->usergroup_manager = $usergroup_manager;
    }
	
/**************************User-Profile************************************/	
	 public function postAccount(Request $request)
    {
	 if(Sentry::check()){
		 $id = Sentry::getUser()->id; 
		 $profile_photo = Sentry::getUser()->photo;
		  $data = $request->input();		
		$validator = Validator::make($request->all(), [	
         // 'username' => 'required',
		  'full_name' => 'required|max:255',
          'email' => 'required|email',
          'address' => 'required',
          'country' => 'required',
		  'state' => 'required',
          'zip_code' => 'required|min:6',		  
		  'phone' => 'required|min:10',          
		  'photo'=>'mimes:png,gif,jpeg,bmp',
        ]);	
        
		if ($validator->fails()) {
          return Redirect::back()->withErrors($validator)->withInput(); 
        } else {
		 // $prof_exitun = DB::table('users')->where('id', '!=', $id)->where('username', '=', $data['username'])->select('id')->get();	
		  $prof_exitem = DB::table('users')->where('id', '!=', $id)->where('email', '=', $data['email'])->select('id')->get();	
		 
		 if(!empty($prof_exitem[0]->id)){
		/* if(!empty($prof_exitun[0]->id)){
		  return Redirect::back()->with('name_error', 'The User name has already been taken.')->withInput();	 
		 } */	 
		 if(!empty($prof_exitem[0]->id)){
		  return Redirect::back()->with('email_error', 'The email has already been taken.')->withInput();	 
		 }		  
        } else {			 
		 /*	$input_file = $request->file();
		 if(!empty($input_file)){			 	
		 $u_filesize = $input_file['photo']->getClientSize();	
		  if ($u_filesize < 2000001) {		 
		  //Upload Image
			$rid = Str::random(3);		 
            $destinationPath = 'public/uploads/user_profile/';	
			
	        $filename = $input_file['photo']->getClientOriginalName();
	        $mime_type = $input_file['photo']->getMimeType();
	        $extension = $input_file['photo']->getClientOriginalExtension();
	        $filename = basename($input_file['photo']->getClientOriginalName(), ".".$extension).'_'.$rid.'.'.$extension;
	        $upload_success = $input_file['photo']->move($destinationPath, $filename);
				
             File::delete($destinationPath.$profile_photo);		
			
			DB::table('users')->where('id', '=', $id)->update(['full_name' => $data['full_name'], 'email' => $data['email'], 'photo' => $filename,'updated_at' => date('Y-m-d H:i:s')]);		   
 
		  } else {			  
			 return redirect($bladename)->with('error', 'Please upload maximum 2mb size file.')->withInput(); 
			die; 
		  }		
         } else {	*/ 
		  DB::table('users')->where('id', '=', $id)->update(['full_name' => $data['full_name'], 'email' => $data['email'],'updated_at' => date('Y-m-d H:i:s')]);		   
       //  }
		DB::table('group_details')->where('u_id', '=', $id)->update(['address' => $data['address'], 'country' => $data['country'], 'state' => $data['state'], 'city' => $data['city'], 'zip_code' => $data['zip_code'], 'phone' =>  $data['phone'], 'updated_at' => date('Y-m-d H:i:s')]); 
		return Redirect::back()->with('succ_mesg', 'Your information updated successfully');       
	  }
	  }
     } else {
		  return Redirect::to('/');
	 }
    } 
	
/**************************User-Account************************************/	
	 public function postCreatedacc(Request $request)
    {
	 if(Sentry::check()){
		 // Sentry::getUser()->id; 
		  $data = $request->input();		
		$validator = Validator::make($request->all(), [	
          'name' => 'required',
		  'account_url' => 'required',	    
		  'phone' => 'required|min:10',
          'email' => 'required|email',
          'address' => 'required',
          'city' => 'required',
		  'state' => 'required',
          'country' => 'required',
          'zip_code' => 'required|min:6',
		  'upload_file'=>'mimes:png,gif,jpeg,bmp',
        ]);		
		if ($validator->fails()) {
          return Redirect::back()->withErrors($validator)->withInput(); 
        } else {
		  $c_exitun = DB::table('account_details')->where('id', '!=', $data['acc_id'])->where('name', '=', $data['name'])->select('id')->get();	
		  $aul_exitun = DB::table('account_details')->where('id', '!=', $data['acc_id'])->where('account_url', '=', $data['account_url'])->select('id')->get();	
		 
		 if(!empty($c_exitun[0]->id) || !empty($aul_exitun[0]->id)){
		 if(!empty($c_exitun[0]->id)){
		  return Redirect::back()->with('name_error', 'The name has already been taken.')->withInput();	 
		 }	 
		 if(!empty($aul_exitun[0]->id)){
		  return Redirect::back()->with('acurl_error', 'The Account URL has already been taken.')->withInput();	 
		 }		  
         } else {			 
			$input_file = $request->file(); 
		  $get_adtls = DB::table('account_details')->where('id', '=', $data['acc_id'])->select('id','g_id','upload_file')->get();	
		 if(!empty($get_adtls[0]->id)){ 
		 if(!empty($input_file)){			 	
		 $u_filesize = $input_file['upload_file']->getClientSize();	
		  if ($u_filesize < 2000001) { 
			
		 if($get_adtls[0]->g_id == 2) {
		  $imgs_apath = 'business';
		 } elseif($get_adtls[0]->g_id == 5) { 
		  $imgs_apath = 'municipality';
         } else {
		  $imgs_apath = 'club';
		 }
		 
		  //Upload Image
			$rid = Str::random(7);		 
            $destinationPath = 'public/uploads/account_type/'.$imgs_apath.'/';	
			
	        $filename = $input_file['upload_file']->getClientOriginalName();
	        $mime_type = $input_file['upload_file']->getMimeType();
	        $extension = $input_file['upload_file']->getClientOriginalExtension();
	        $filename = basename($input_file['upload_file']->getClientOriginalName(), ".".$extension).'_'.$rid.'.'.$extension;
	        $upload_success = $input_file['upload_file']->move($destinationPath, $filename);


			/***************resize-image****************/
			    // and insert a watermark for example
                //$img->insert('public/watermark.png');
			  /*$rsfname = basename($input_file['upload_file']->getClientOriginalName(), ".".$extension).'_'.$rid.'_200x200.'.$extension;
			  $rspath = public_path('uploads/account_type/'.$imgs_apath.'/'.$rsfname);
			  Image::make($destinationPath.$filename)->resize(200, 200)->save($rspath);				 */
			/******************************************/
				
             File::delete($destinationPath.$get_adtls[0]->upload_file);		
			
			DB::table('account_details')->where('id', '=', $data['acc_id'])->update(['name' => $data['name'], 'account_url' => $data['account_url'], 'address' => $data['address'], 'city' => $data['city'],
		  'email' => $data['email'], 'state' => $data['state'], 'website' => $data['website'], 'zip_code' => $data['zip_code'], 'upload_file' => $filename, 'country' =>  $data['country'],
		  'phone' => $data['phone'], 'updated_at' => date('Y-m-d H:i:s')]);		   

		  } else {			  
			 return redirect($bladename)->with('error', 'Please upload maximum 2mb size file.')->withInput(); 
			die; 
		  }		
         } else {	 
		  DB::table('account_details')->where('id', '=', $data['acc_id'])->update(['name' => $data['name'], 'account_url' => $data['account_url'], 'address' => $data['address'], 'city' => $data['city'],
		  'email' => $data['email'], 'state' => $data['state'], 'website' => $data['website'], 'zip_code' => $data['zip_code'], 'country' =>  $data['country'], 'phone' => $data['phone'],
		  'updated_at' => date('Y-m-d H:i:s')]);
         }
		   return Redirect::to($data['account_url'].'/account')->with('succ_mesg', 'Your account information updated successfully');
        }	
          return Redirect::back()->with('error', 'Something wrong! please try again')->withInput();
		 } 
		}
     } else {
		  return Redirect::to('/');
	 }
    }
     public function postAccfollow(Request $request)
    {
	 if(Sentry::check()){
	    $uid = Sentry::getUser()->id; 
	   $data = $request->input();
       $get_ownerid = DB::table('account_details')->where('id', '=', $data['ascid'])->select('u_id','name')->get();
     if(!empty($get_ownerid[0]->u_id)){	   
	  $cflw = DB::table('user_follows')->where('follow_id', '=', $data['ascid'])->where('u_id', '=', $uid)->select('id')->get();
	 if(empty($cflw[0]->id)){ 
	  DB::table('user_follows')->insert(['follow_id' => $data['ascid'], 'u_id' => $uid, 'owner_id' => $get_ownerid[0]->u_id,
	  'follow_type' => 'account', 'created_at' => date('Y-m-d H:i:s'), 'updated_at' => date('Y-m-d H:i:s')]); 	  
	   $notfsub = '<span class="ntf-uname">'.Sentry::getUser()->full_name.'</span> follow a page <span class="ntf-data">"'.$get_ownerid[0]->name.'"</span>'; 	  
	  DB::table('notifications')->insert(['onr_id' => $get_ownerid[0]->u_id,'u_id' => $uid,'type' => 'page','subject' => $notfsub,
	 'object_id' => $data['ascid'],'object_type'=> 'follow','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')]);
	 }
	  return 'success';	  
	 }       	  
	 } else {
	  return 'error';	 
	 }	
	}
	
	 public function postUnfollow(Request $request)
    {
	 if(Sentry::check()){
	    $uid = Sentry::getUser()->id; 
	   $data = $request->input();
       $check_flws = DB::table('user_follows')->where('id', '=', $data['flwid'])->where('u_id', '=', $uid)->select('id','follow_id','owner_id')->get();
     if(!empty($check_flws[0]->id)){	   
	 // DB::delete('delete from user_follows WHERE id = '.$check_flws[0]->id);    
	  DB::table('user_follows')->where('id', '=', $check_flws[0]->id)->update(['follow' => 'n', 'updated_at' => date('Y-m-d H:i:s')]);	
	  $get_ownerid = DB::table('account_details')->where('id', '=', $check_flws[0]->follow_id)->select('u_id','name')->get();
	   $notfsub = '<span class="ntf-uname">'.Sentry::getUser()->full_name.'</span> unfollow a page <span class="ntf-data">"'.$get_ownerid[0]->name.'"</span>'; 	 
	  DB::table('notifications')->insert(['onr_id' => $check_flws[0]->owner_id,'u_id' => $uid,'type' => 'page','subject' => $notfsub,
	 'object_id' => $check_flws[0]->follow_id,'object_type'=> 'follow','created_at' => date('Y-m-d H:i:s'),'updated_at' => date('Y-m-d H:i:s')]);
	  return 'succ';
	 } else {
	  return 'error';	 
	 }       	  
	 } else {
	  return Redirect::to('/');	 
	 }	
	}
	
  public function getScdata($getdata, $id)
  {
	if(!empty($getdata)){
	  if($getdata == 'state'){
		 $state_data = DB::table('states')->where('country_id', '=', $id)->select('id','name')->get();  
		if(!empty($state_data[0]->id)){	
           echo '<option value="'.$state_data[0]->id.'" selected>'.$state_data[0]->name.'</option>';		
		 foreach($state_data as $sd){ 
		  if($sd->id != $state_data[0]->id){
		   echo '<option value="'.$sd->id.'">'.$sd->name.'</option>';
		  } 
		 }
		}
       die;		
	  } else {
		 $city_data = DB::table('cities')->where('state_id', '=', $id)->select('id','name')->get();  
		if(!empty($city_data[0]->id)){			
		 foreach($city_data as $cd){ 
		  echo '<option value="'.$cd->id.'">'.$cd->name.'</option>';
		 }
		} else {
		 echo '<option value="">Not available</option>';	
		}
       die;	  
	  }
	}  
  }
}